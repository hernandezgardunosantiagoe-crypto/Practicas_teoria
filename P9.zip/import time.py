import time

class MaquinaTuringUniversal:
    def __init__(self, cinta_completa):
        self.transiciones = {}
        self.estado_actual = "1"  # q0 en unario (1)
        self.cabezal = 0
        
        # Desensamblar la cinta usando los separadores
        self.decodificar_cinta(cinta_completa)

    def decodificar_cinta(self, cinta_completa):
        """Separa las reglas de la máquina (M) de la entrada (w) usando '000'."""
        partes = cinta_completa.split("000")
        
        if len(partes) < 2:
            print("Error: No se encontró el separador '000' entre M y w.")
            self.cinta = []
            return

        # 1. Procesar la máquina M (separador '00' entre transiciones)
        reglas_crudas = partes[0].split("00")
        for regla in reglas_crudas:
            if not regla: continue
            
            # Separador '0' entre los elementos de la tupla
            elementos = regla.split("0")
            if len(elementos) == 5:
                q_origen, leo, q_destino, escribo, direccion = elementos
                self.transiciones[(q_origen, leo)] = {
                    "q_destino": q_destino,
                    "escribo": escribo,
                    "direccion": direccion
                }
        
        # 2. Procesar la entrada w (asumimos que los símbolos de entrada vienen separados por '0')
        # Si la entrada está vacía, inicializamos con un espacio en blanco (1 en unario)
        entrada_w = partes[1]
        if entrada_w:
            self.cinta = entrada_w.split("0")
        else:
            self.cinta = ["1"] 

    def simular(self, retardo=0.5):
        """Ejecuta la MTU paso a paso mostrando la cinta en consola."""
        print("\n--- INICIANDO SIMULACIÓN DE MTU ---")
        paso = 1
        
        while True:
            # Leer símbolo actual (si el cabezal sale de los límites, agregar blancos '1')
            if self.cabezal < 0:
                self.cinta.insert(0, "1")
                self.cabezal = 0
            elif self.cabezal >= len(self.cinta):
                self.cinta.append("1")
                
            simbolo_leido = self.cinta[self.cabezal]
            clave_transicion = (self.estado_actual, simbolo_leido)
            
            # Imprimir estado actual de la cinta y cabezal
            cinta_visual = " | ".join(self.cinta)
            print(f"Paso {paso} | Estado: {self.estado_actual}")
            print(f"Cinta: [ {cinta_visual} ]")
            print(" " * (9 + self.cabezal * 4 + len(self.cinta[self.cabezal]) // 2) + "^")
            
            # Verificar si existe una transición definida
            if clave_transicion not in self.transiciones:
                print("-> No hay transición definida. MÁQUINA DETENIDA.\n")
                break
                
            # Aplicar transición
            regla = self.transiciones[clave_transicion]
            self.cinta[self.cabezal] = regla["escribo"]
            self.estado_actual = regla["q_destino"]
            
            # Mover cabezal (1 = Izquierda, 11 = Derecha, 111 = Quieto)
            if regla["direccion"] == "1":
                self.cabezal -= 1
            elif regla["direccion"] == "11":
                self.cabezal += 1
                
            paso += 1
            time.sleep(retardo) # Pausa para visualización paso a paso

# --- EJEMPLO DE USO ---
if __name__ == "__main__":
    # --- MÁQUINA 3: Incremento Binario (+1) ---
    # Estados: q0=1, q1=11, q_acepta=111
    # Símbolos: Blanco=1, 0=11, 1=111
    # Direcciones: L=1, R=11, S=111
    
    reglas_m3 = [
        "101101011011",         # q0 lee 0 -> q0 escribe 0, R (avanza al final)
        "10111010111011",       # q0 lee 1 -> q0 escribe 1, R (avanza al final)
        "1010110101",           # q0 lee B -> q1, L (empieza a sumar de der a izq)
        "11011101101101",       # q1 lee 1 -> q1 escribe 0, L (llevo 1)
        "11011011101110111",    # q1 lee 0 -> q_acepta escribe 1, S (termina suma)
        "1101011101110111"      # q1 lee B -> q_acepta escribe 1, S (desbordamiento, ej. 11+1=100)
    ]
    
    maquina_codificada = "00".join(reglas_m3)

    entradas = {
        "Válida '0'": "11",
        "Válida '10'": "111011",
        "Válida '11'": "1110111",
        "No Válida 'a'": "1111",       # Símbolo no definido, crashea
        "No Válida 'b1'": "111110111", # Símbolo no definido, crashea
        "No Válida '0a'": "1101111"    # Letra intrusa, crashea
    }

    for nombre, entrada_codificada in entradas.items():
        print(f"\n{'='*50}")
        print(f"PROBANDO CADENA (M3): {nombre}")
        print(f"{'='*50}")
        cinta_final = f"{maquina_codificada}000{entrada_codificada}"
        mtu = MaquinaTuringUniversal(cinta_final)
        mtu.simular(retardo=0.05)