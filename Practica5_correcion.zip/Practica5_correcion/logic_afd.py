"""
logic_afd.py — Lógica para Autómata Finito Determinista (AFD)
Extraído del main.py original para modularidad.
"""


def simular_AFD(transiciones: dict, estado_inicial: str,
                estados_aceptacion: set, cadena: str) -> dict:
    """
    Simula un AFD.
    transiciones = { "q0": {"a": "q1", "b": "q0"}, ... }
    """
    estado_actual = estado_inicial
    camino = [estado_actual]
    pasos  = []

    for simbolo in cadena:
        if estado_actual not in transiciones:
            pasos.append((estado_actual, simbolo, None, "Estado sin transiciones"))
            return {"aceptada": False, "camino": camino, "pasos": pasos}
        if simbolo not in transiciones[estado_actual]:
            pasos.append((estado_actual, simbolo, None, "Transición no definida"))
            return {"aceptada": False, "camino": camino, "pasos": pasos}

        siguiente = transiciones[estado_actual][simbolo]
        pasos.append((estado_actual, simbolo, siguiente, "OK"))
        estado_actual = siguiente
        camino.append(estado_actual)

    aceptada = estado_actual in estados_aceptacion
    return {"aceptada": aceptada, "camino": camino, "pasos": pasos}


def formatear_resultado_automata(resultado: dict, cadena: str,
                                  estado_inicial: str,
                                  estados_aceptacion: set) -> str:
    aceptada = resultado["aceptada"]
    texto  = "TIPO: AFD\n"
    texto += f"CADENA EVALUADA: '{cadena}'\n"
    texto += f"ESTADO INICIAL: {estado_inicial}\n"
    texto += f"ESTADOS DE ACEPTACIÓN: {{{', '.join(sorted(estados_aceptacion))}}}\n\n"
    texto += "─── TRAZA DE EJECUCIÓN ───\n"

    for i, (src, sym, dst, nota) in enumerate(resultado["pasos"]):
        dst_str = dst if dst else "∅"
        texto += f"  Paso {i+1}: δ({src}, '{sym}') → {dst_str}   [{nota}]\n"

    texto += f"\nCAMINO: {' → '.join(resultado['camino'])}\n"
    texto += "\n" + "=" * 35 + "\n"
    texto += f"RESULTADO: {'CADENA ACEPTADA' if aceptada else 'CADENA RECHAZADA'}\n"
    texto += "=" * 35 + "\n"
    return texto
