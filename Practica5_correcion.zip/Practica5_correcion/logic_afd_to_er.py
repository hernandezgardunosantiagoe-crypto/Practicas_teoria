"""
logic_afd_to_er.py — Conversión de AFD a Expresión Regular (ER)
usando el algoritmo de Eliminación de Estados (GNFA).
"""
import copy


# ─────────────────────────────────────────────────────────────────
#  Operaciones de ER (simplificación básica)
# ─────────────────────────────────────────────────────────────────

def _union(a: str, b: str) -> str:
    """Une dos expresiones regulares con '|'."""
    if not a or a == "∅":
        return b
    if not b or b == "∅":
        return a
    if a == b:
        return a
    return f"({a}|{b})"


def _concat(a: str, b: str) -> str:
    """Concatena dos expresiones regulares."""
    if not a or not b or a == "∅" or b == "∅":
        return "∅"
    if a == "ε":
        return b
    if b == "ε":
        return a
    # Añadir paréntesis si contienen alternativa
    a_p = f"({a})" if "|" in a and not (a.startswith("(") and a.endswith(")")) else a
    b_p = f"({b})" if "|" in b and not (b.startswith("(") and b.endswith(")")) else b
    return f"{a_p}{b_p}"


def _star(a: str) -> str:
    """Aplica la cerradura de Kleene a una ER."""
    if not a or a == "∅" or a == "ε":
        return "ε"
    if len(a) == 1:
        return f"{a}*"
    return f"({a})*"


# ─────────────────────────────────────────────────────────────────
#  Conversión AFD → GNFA → ER
# ─────────────────────────────────────────────────────────────────

def afd_a_er(transiciones: dict, estado_inicial: str,
             estados_aceptacion: set) -> dict:
    """
    Convierte un AFD a expresión regular usando eliminación de estados.
    Retorna un dict con la ER resultante y los pasos detallados.
    """
    # ── 1. Construir GNFA con estado inicial qI y estado final qF ──
    QI = "__QI__"
    QF = "__QF__"

    # gnfa[src][dst] = expresión regular del arco src→dst
    gnfa: dict = {}

    # Inicializar todos los pares con ∅
    todos = [QI] + list(transiciones.keys()) + [QF]

    for s in todos:
        gnfa[s] = {}
        for t in todos:
            gnfa[s][t] = "∅"

    # Arco ε del nuevo inicial al inicial original
    gnfa[QI][estado_inicial] = "ε"

    # Arcos ε de cada estado de aceptación al nuevo final
    for ea in estados_aceptacion:
        gnfa[ea][QF] = _union(gnfa[ea][QF], "ε")

    # Poblar transiciones originales del AFD
    for src, trans in transiciones.items():
        for sym, dst in trans.items():
            if dst and dst != "∅":
                gnfa[src][dst] = _union(gnfa[src][dst], sym)

    pasos = []
    pasos.append({
        "descripcion": "GNFA inicial construido",
        "gnfa": _serializar_gnfa(gnfa, todos),
        "estados": list(todos),
    })

    # ── 2. Eliminar estados internos uno a uno ──
    estados_internos = list(transiciones.keys())

    for eliminar in estados_internos:
        loop = gnfa[eliminar][eliminar]  # auto-lazo del estado a eliminar

        # Para cada par (qi, qj) donde qi != eliminar y qj != eliminar
        nuevos_estados = [e for e in todos if e != eliminar]
        for qi in nuevos_estados:
            if qi == eliminar:
                continue
            for qj in nuevos_estados:
                if qj == eliminar:
                    continue
                # R(qi,qj) = R(qi,qj) | R(qi,elim) R(loop)* R(elim,qj)
                r_qi_elim = gnfa[qi][eliminar]
                r_elim_qj = gnfa[eliminar][qj]
                if r_qi_elim != "∅" and r_elim_qj != "∅":
                    middle = _concat(_star(loop), r_elim_qj) if loop != "∅" else r_elim_qj
                    nuevo = _concat(r_qi_elim, middle)
                    gnfa[qi][qj] = _union(gnfa[qi][qj], nuevo)

        # Eliminar el estado del GNFA
        todos = [e for e in todos if e != eliminar]
        for s in todos:
            gnfa[s].pop(eliminar, None)
        gnfa.pop(eliminar, None)

        pasos.append({
            "descripcion": f"Eliminado estado: {eliminar}",
            "gnfa": _serializar_gnfa(gnfa, todos),
            "estados": list(todos),
        })

    # ── 3. La ER final es el arco QI → QF ──
    er_final = gnfa.get(QI, {}).get(QF, "∅")
    if not er_final or er_final == "∅":
        er_final = "∅  (lenguaje vacío)"

    return {
        "er": er_final,
        "pasos": pasos,
        "estado_inicial": estado_inicial,
        "estados_aceptacion": estados_aceptacion,
    }


def _serializar_gnfa(gnfa: dict, estados: list) -> list:
    """Convierte el GNFA a lista de arcos para mostrar."""
    arcos = []
    for s in estados:
        for t in estados:
            er = gnfa.get(s, {}).get(t, "∅")
            if er and er != "∅":
                arcos.append({"de": s, "a": t, "er": er})
    return arcos


# ─────────────────────────────────────────────────────────────────
#  Formato de salida
# ─────────────────────────────────────────────────────────────────

def formatear_afd_a_er(resultado: dict) -> str:
    texto  = "CONVERSIÓN: AFD → Expresión Regular\n"
    texto += "Algoritmo: Eliminación de Estados (GNFA)\n"
    texto += "=" * 50 + "\n\n"

    texto += "─── PROCESO PASO A PASO ───\n\n"
    for i, paso in enumerate(resultado["pasos"]):
        texto += f"[Paso {i}] {paso['descripcion']}\n"
        arcos = paso["gnfa"]
        if arcos:
            for arco in arcos:
                src = arco["de"].replace("__QI__", "q_inicio").replace("__QF__", "q_final")
                dst = arco["a"].replace("__QI__", "q_inicio").replace("__QF__", "q_final")
                texto += f"    {src} ──[{arco['er']}]──▶ {dst}\n"
        else:
            texto += "    (sin arcos)\n"
        texto += "\n"

    texto += "=" * 50 + "\n"
    texto += f"EXPRESIÓN REGULAR RESULTANTE:\n\n  {resultado['er']}\n\n"
    texto += "=" * 50 + "\n"
    return texto


# ─────────────────────────────────────────────────────────────────
#  Validar que el autómata sea un AFD válido
# ─────────────────────────────────────────────────────────────────

def validar_afd(transiciones: dict, estado_inicial: str,
                estados_aceptacion: set, simbolos: list) -> tuple[bool, str]:
    """
    Verifica que el autómata sea un AFD válido.
    Retorna (es_valido, mensaje).
    """
    if not estado_inicial:
        return False, "No se definió estado inicial."
    if estado_inicial not in transiciones:
        return False, f"El estado inicial '{estado_inicial}' no tiene transiciones definidas."
    if not estados_aceptacion:
        return False, "No se definieron estados de aceptación."
    for ea in estados_aceptacion:
        if ea not in transiciones:
            return False, f"El estado de aceptación '{ea}' no existe en la tabla."

    # Verificar determinismo: cada estado debe tener exactamente 1 destino por símbolo
    for estado, trans in transiciones.items():
        for sym in simbolos:
            dest = trans.get(sym)
            if dest is None or dest == "":
                return False, f"Falta transición: δ({estado}, '{sym}') no está definida."
            if dest not in transiciones:
                return False, f"Estado destino '{dest}' no existe (desde δ({estado}, '{sym}'))."

    return True, "AFD válido ✅"
