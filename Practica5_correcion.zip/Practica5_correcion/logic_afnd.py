"""
logic_afnd.py — Lógica para Autómata Finito No Determinista (AFND)
"""
from collections import defaultdict


def simular_AFND(transiciones: dict, estado_inicial: str,
                 estados_aceptacion: set, cadena: str) -> dict:
    """
    Simula un AFND (sin lambda).
    transiciones = { "q0": {"a": {"q1","q2"}, "b": {"q0"} }, ... }
    """
    estados_actuales = {estado_inicial}
    historial = []  # lista de (conjunto_actual, simbolo, conjunto_siguiente)

    for simbolo in cadena:
        siguientes = set()
        for estado in estados_actuales:
            destinos = transiciones.get(estado, {}).get(simbolo, set())
            siguientes |= set(destinos)
        historial.append((frozenset(estados_actuales), simbolo, frozenset(siguientes)))
        estados_actuales = siguientes
        if not estados_actuales:
            break

    aceptada = bool(estados_actuales & estados_aceptacion)
    return {
        "aceptada": aceptada,
        "historial": historial,
        "estados_finales": frozenset(estados_actuales),
    }


def formatear_resultado_afnd(resultado: dict, cadena: str,
                              estado_inicial: str,
                              estados_aceptacion: set) -> str:
    aceptada = resultado["aceptada"]
    texto  = "TIPO: AFND\n"
    texto += f"CADENA EVALUADA: '{cadena}'\n"
    texto += f"ESTADO INICIAL: {estado_inicial}\n"
    texto += f"ESTADOS DE ACEPTACIÓN: {{{', '.join(sorted(estados_aceptacion))}}}\n\n"
    texto += "─── TRAZA DE EJECUCIÓN ───\n"

    for i, (src, sym, dst) in enumerate(resultado["historial"]):
        src_str = "{" + ", ".join(sorted(src)) + "}"
        dst_str = "{" + ", ".join(sorted(dst)) + "}" if dst else "∅"
        texto += f"  Paso {i+1}: δ({src_str}, '{sym}') → {dst_str}\n"

    ef = resultado["estados_finales"]
    ef_str = "{" + ", ".join(sorted(ef)) + "}" if ef else "∅"
    texto += f"\nESTADOS FINALES ALCANZADOS: {ef_str}\n"
    texto += "\n" + "=" * 35 + "\n"
    texto += f"RESULTADO: {'CADENA ACEPTADA' if aceptada else 'CADENA RECHAZADA'}\n"
    texto += "=" * 35 + "\n"
    return texto
