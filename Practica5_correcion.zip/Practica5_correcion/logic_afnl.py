"""
logic_afnl.py — Lógica para AFN-λ (AFND con transiciones lambda/epsilon)
"""


def lambda_clausura(estado: str, transiciones_lambda: dict) -> set:
    """Calcula la λ-clausura de un único estado."""
    clausura = {estado}
    pila = [estado]
    while pila:
        actual = pila.pop()
        for dest in transiciones_lambda.get(actual, set()):
            if dest not in clausura:
                clausura.add(dest)
                pila.append(dest)
    return clausura


def lambda_clausura_conjunto(estados: set, transiciones_lambda: dict) -> set:
    """Calcula la λ-clausura de un conjunto de estados."""
    resultado = set()
    for e in estados:
        resultado |= lambda_clausura(e, transiciones_lambda)
    return resultado


def simular_AFNL(transiciones: dict, transiciones_lambda: dict,
                 estado_inicial: str, estados_aceptacion: set,
                 cadena: str) -> dict:
    """
    Simula un AFN-λ.
    transiciones         = { "q0": {"a": {"q1"}}, ... }
    transiciones_lambda  = { "q0": {"q1"}, ... }  (transiciones con ε/λ)
    """
    estados_actuales = lambda_clausura(estado_inicial, transiciones_lambda)
    historial = []

    for simbolo in cadena:
        # 1. Mover con el símbolo
        siguientes_raw = set()
        for estado in estados_actuales:
            destinos = transiciones.get(estado, {}).get(simbolo, set())
            siguientes_raw |= set(destinos)
        # 2. Aplicar λ-clausura al resultado
        siguientes = lambda_clausura_conjunto(siguientes_raw, transiciones_lambda)
        historial.append({
            "conjunto_antes": frozenset(estados_actuales),
            "simbolo": simbolo,
            "tras_transicion": frozenset(siguientes_raw),
            "tras_clausura": frozenset(siguientes),
        })
        estados_actuales = siguientes
        if not estados_actuales:
            break

    aceptada = bool(estados_actuales & estados_aceptacion)
    return {
        "aceptada": aceptada,
        "historial": historial,
        "estados_finales": frozenset(estados_actuales),
    }


def formatear_resultado_afnl(resultado: dict, cadena: str,
                               estado_inicial: str,
                               estados_aceptacion: set) -> str:
    aceptada = resultado["aceptada"]
    texto  = "TIPO: AFN-λ\n"
    texto += f"CADENA EVALUADA: '{cadena}'\n"
    texto += f"ESTADO INICIAL: {estado_inicial}\n"
    texto += f"ESTADOS DE ACEPTACIÓN: {{{', '.join(sorted(estados_aceptacion))}}}\n\n"
    texto += "─── TRAZA DE EJECUCIÓN ───\n"

    for i, paso in enumerate(resultado["historial"]):
        src  = "{" + ", ".join(sorted(paso["conjunto_antes"])) + "}"
        raw  = "{" + ", ".join(sorted(paso["tras_transicion"])) + "}" if paso["tras_transicion"] else "∅"
        cla  = "{" + ", ".join(sorted(paso["tras_clausura"])) + "}" if paso["tras_clausura"] else "∅"
        texto += f"  Paso {i+1}: δ({src}, '{paso['simbolo']}') = {raw}  → λ-clausura = {cla}\n"

    ef = resultado["estados_finales"]
    ef_str = "{" + ", ".join(sorted(ef)) + "}" if ef else "∅"
    texto += f"\nESTADOS FINALES ALCANZADOS: {ef_str}\n"
    texto += "\n" + "=" * 35 + "\n"
    texto += f"RESULTADO: {'CADENA ACEPTADA' if aceptada else 'CADENA RECHAZADA'}\n"
    texto += "=" * 35 + "\n"
    return texto


def calcular_todas_clausuras(estados: list, transiciones_lambda: dict) -> dict:
    """Devuelve un dict {estado: lambda_clausura} para todos los estados."""
    return {e: lambda_clausura(e, transiciones_lambda) for e in estados}
