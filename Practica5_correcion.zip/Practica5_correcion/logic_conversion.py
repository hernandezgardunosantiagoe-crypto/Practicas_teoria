"""
logic_conversion.py — Conversión entre tipos de autómatas
  - AFND → AFD (algoritmo de subconjuntos)
  - AFN-λ → AFND (eliminación de transiciones lambda)
"""
from logic_afnl import lambda_clausura, lambda_clausura_conjunto


# ─────────────────────────────────
#  AFND → AFD (subconjuntos)
# ─────────────────────────────────

def afnd_a_afd(transiciones_nd: dict, estado_inicial: str,
               estados_aceptacion: set, simbolos: list) -> dict:
    """
    Convierte AFND → AFD usando el algoritmo de subconjuntos.
    Retorna dict con todos los datos del AFD resultante + pasos.
    """
    inicial_set = frozenset({estado_inicial})
    cola   = [inicial_set]
    vistos = {inicial_set}
    trans_afd   = {}
    pasos       = []   # lista de dicts para visualizar el proceso

    while cola:
        conjunto = cola.pop(0)
        nombre   = _nombre_conjunto(conjunto)
        trans_afd[nombre] = {}

        for sym in simbolos:
            destino = set()
            for estado in conjunto:
                destino |= set(transiciones_nd.get(estado, {}).get(sym, set()))
            dest_frozen = frozenset(destino)
            dest_nombre = _nombre_conjunto(dest_frozen) if dest_frozen else "∅"
            trans_afd[nombre][sym] = dest_nombre

            pasos.append({
                "origen": nombre,
                "simbolo": sym,
                "destino": dest_nombre,
            })

            if dest_frozen and dest_frozen not in vistos:
                vistos.add(dest_frozen)
                cola.append(dest_frozen)

    # Determinar estados de aceptación del AFD
    estados_acept_afd = set()
    for conj in vistos:
        if conj & estados_aceptacion:
            estados_acept_afd.add(_nombre_conjunto(conj))

    estado_inicial_afd = _nombre_conjunto(inicial_set)
    return {
        "transiciones": trans_afd,
        "estado_inicial": estado_inicial_afd,
        "estados_aceptacion": estados_acept_afd,
        "estados": list(trans_afd.keys()),
        "simbolos": simbolos,
        "pasos": pasos,
    }


def formatear_conversion_afnd_afd(resultado: dict) -> str:
    texto  = "CONVERSIÓN: AFND → AFD (Algoritmo de Subconjuntos)\n"
    texto += "=" * 50 + "\n\n"
    texto += "─── TABLA DE TRANSICIONES DEL AFD ───\n"
    texto += f"{'Estado':<20}" + "".join(f"{s:<12}" for s in resultado["simbolos"]) + "\n"
    texto += "-" * (20 + 12 * len(resultado["simbolos"])) + "\n"

    for estado, trans in resultado["transiciones"].items():
        marcador = "→" if estado == resultado["estado_inicial"] else " "
        marcador += "*" if estado in resultado["estados_aceptacion"] else " "
        fila = f"{marcador} {estado:<18}"
        for sym in resultado["simbolos"]:
            fila += f"{trans.get(sym, '∅'):<12}"
        texto += fila + "\n"

    texto += f"\nESTADO INICIAL: {resultado['estado_inicial']}\n"
    texto += f"ESTADOS DE ACEPTACIÓN: {{{', '.join(sorted(resultado['estados_aceptacion']))}}}\n"
    texto += f"TOTAL DE ESTADOS: {len(resultado['estados'])}\n"
    return texto


# ─────────────────────────────────
#  AFN-λ → AFND (eliminar lambdas)
# ─────────────────────────────────

def afnl_a_afnd(transiciones: dict, transiciones_lambda: dict,
                estado_inicial: str, estados_aceptacion: set,
                estados: list, simbolos: list) -> dict:
    """
    Elimina las transiciones lambda de un AFN-λ, produciendo un AFND equivalente.
    """
    nuevas_trans = {}
    pasos = []

    for estado in estados:
        nuevas_trans[estado] = {}
        clausura_e = lambda_clausura(estado, transiciones_lambda)

        for sym in simbolos:
            alcanzables = set()
            for e_cl in clausura_e:
                destinos_raw = set(transiciones.get(e_cl, {}).get(sym, set()))
                alcanzables |= lambda_clausura_conjunto(destinos_raw, transiciones_lambda)

            nuevas_trans[estado][sym] = alcanzables
            pasos.append({
                "estado": estado,
                "clausura": clausura_e,
                "simbolo": sym,
                "destino": alcanzables,
            })

    # Recalcular estados de aceptación
    nuevos_acept = set()
    for estado in estados:
        if lambda_clausura(estado, transiciones_lambda) & estados_aceptacion:
            nuevos_acept.add(estado)

    return {
        "transiciones": nuevas_trans,
        "estado_inicial": estado_inicial,
        "estados_aceptacion": nuevos_acept,
        "estados": estados,
        "simbolos": simbolos,
        "pasos": pasos,
    }


def formatear_eliminacion_lambda(resultado: dict) -> str:
    texto  = "CONVERSIÓN: AFN-λ → AFND (Eliminación de λ-transiciones)\n"
    texto += "=" * 55 + "\n\n"
    texto += "─── TABLA DE TRANSICIONES DEL AFND RESULTANTE ───\n"
    texto += f"{'Estado':<15}" + "".join(f"{s:<15}" for s in resultado["simbolos"]) + "\n"
    texto += "-" * (15 + 15 * len(resultado["simbolos"])) + "\n"

    for estado in resultado["estados"]:
        marcador = "→" if estado == resultado["estado_inicial"] else " "
        marcador += "*" if estado in resultado["estados_aceptacion"] else " "
        fila = f"{marcador} {estado:<13}"
        for sym in resultado["simbolos"]:
            dest = resultado["transiciones"].get(estado, {}).get(sym, set())
            dest_str = "{" + ",".join(sorted(dest)) + "}" if dest else "∅"
            fila += f"{dest_str:<15}"
        texto += fila + "\n"

    texto += f"\nESTADO INICIAL: {resultado['estado_inicial']}\n"
    texto += f"ESTADOS DE ACEPTACIÓN: {{{', '.join(sorted(resultado['estados_aceptacion']))}}}\n"
    return texto


# ─────────────────────────────────
#  Helpers
# ─────────────────────────────────

def _nombre_conjunto(conj: frozenset) -> str:
    if not conj:
        return "∅"
    return "{" + ",".join(sorted(conj)) + "}"
