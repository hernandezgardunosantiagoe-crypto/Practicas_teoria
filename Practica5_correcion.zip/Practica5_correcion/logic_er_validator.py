"""
logic_er_validator.py — Validadores prácticos con Expresiones Regulares (Ejercicio 3)

Casos de uso implementados:
  1. Validador de correo electrónico
  2. Validador de número telefónico (formato nacional mexicano)
  3. Validador de URL
  4. Validador de fecha (varios formatos)
  5. Validador de contraseña (criterios específicos)

Para cada uno se expone:
  - La expresión regular utilizada
  - La función de validación
  - Sugerencias de corrección cuando falla
"""
import re


# ─────────────────────────────────────────────────────────────────
#  Definiciones de patrones
# ─────────────────────────────────────────────────────────────────

PATRONES = {
    "email": {
        "nombre": "Correo electrónico",
        "er": r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$",
        "descripcion": "usuario@dominio.extension",
        "ejemplos_validos": ["usuario@ejemplo.com", "nombre.apellido@empresa.org", "test+tag@mail.co"],
        "ejemplos_invalidos": ["usuario@", "@dominio.com", "sin_arroba.com"],
    },
    "telefono": {
        "nombre": "Teléfono (México)",
        "er": r"^(\+52\s?)?(\(?\d{2,3}\)?[\s\-]?)?\d{3,4}[\s\-]?\d{4}$",
        "descripcion": "(+52) (XX) XXXX-XXXX  o  XXXXXXXXXX",
        "ejemplos_validos": ["+52 55 1234 5678", "5512345678", "55 1234-5678", "(55)12345678"],
        "ejemplos_invalidos": ["123", "abcd-efgh", "55 12 34"],
    },
    "url": {
        "nombre": "URL",
        "er": r"^(https?|ftp):\/\/(www\.)?[a-zA-Z0-9\-]+(\.[a-zA-Z]{2,})+([\/\w\-._~:/?#\[\]@!$&'()*+,;=%]*)?$",
        "descripcion": "http(s)://dominio.ext/ruta",
        "ejemplos_validos": ["https://www.ejemplo.com", "http://sitio.org/pagina", "ftp://files.server.net"],
        "ejemplos_invalidos": ["www.sin-protocolo.com", "http://", "no_es_url"],
    },
    "fecha": {
        "nombre": "Fecha",
        "er": r"^(\d{2}[\/\-\.]\d{2}[\/\-\.]\d{4}|\d{4}[\/\-\.]\d{2}[\/\-\.]\d{2})$",
        "descripcion": "DD/MM/AAAA  o  AAAA-MM-DD  (separadores: / - .)",
        "ejemplos_validos": ["25/12/2024", "2024-01-15", "01.06.2023", "1999/07/04"],
        "ejemplos_invalidos": ["25-13-2024", "2024", "dd/mm/aaaa"],
    },
    "contrasena": {
        "nombre": "Contraseña segura",
        "er": r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?]).{8,}$",
        "descripcion": "Mín. 8 caracteres: mayúscula, minúscula, número y símbolo especial",
        "ejemplos_validos": ["Segura@123", "MiClave#9!", "Abc123$xyz"],
        "ejemplos_invalidos": ["password", "12345678", "SinSimbolos1", "corta@1A"],
    },
}


# ─────────────────────────────────────────────────────────────────
#  Validación
# ─────────────────────────────────────────────────────────────────

def validar(tipo: str, texto: str) -> dict:
    """
    Valida 'texto' usando el patrón del tipo indicado.
    Retorna dict con: valido, er, sugerencias, descripcion.
    """
    if tipo not in PATRONES:
        return {"valido": False, "er": "", "sugerencias": ["Tipo de validador desconocido."],
                "descripcion": ""}

    info = PATRONES[tipo]
    patron = info["er"]
    valido = bool(re.match(patron, texto))
    sugerencias = _generar_sugerencias(tipo, texto) if not valido else []

    return {
        "valido": valido,
        "er": patron,
        "sugerencias": sugerencias,
        "descripcion": info["descripcion"],
        "nombre": info["nombre"],
        "ejemplos_validos": info["ejemplos_validos"],
    }


# ─────────────────────────────────────────────────────────────────
#  Sugerencias de corrección
# ─────────────────────────────────────────────────────────────────

def _generar_sugerencias(tipo: str, texto: str) -> list:
    sugerencias = []

    if tipo == "email":
        if "@" not in texto:
            sugerencias.append("Falta el símbolo '@'.")
        else:
            partes = texto.split("@")
            if len(partes[0]) == 0:
                sugerencias.append("El nombre de usuario está vacío antes de '@'.")
            if len(partes) > 1 and "." not in partes[1]:
                sugerencias.append("El dominio debe contener al menos un punto, ej: dominio.com")
            if len(partes) > 1 and partes[1].endswith("."):
                sugerencias.append("El dominio no puede terminar con punto.")
        if " " in texto:
            sugerencias.append("El correo no debe contener espacios.")

    elif tipo == "telefono":
        digitos = re.sub(r"[^\d]", "", texto)
        if len(digitos) < 10:
            sugerencias.append(f"Faltan dígitos. Tienes {len(digitos)}, se requieren al menos 10.")
        if len(digitos) > 13:
            sugerencias.append("Demasiados dígitos.")
        if re.search(r"[a-zA-Z]", texto):
            sugerencias.append("El número no debe contener letras.")
        if not sugerencias:
            sugerencias.append("Formato esperado: (+52) (55) XXXX-XXXX o 10 dígitos continuos.")

    elif tipo == "url":
        if not texto.startswith(("http://", "https://", "ftp://")):
            sugerencias.append("La URL debe comenzar con 'http://', 'https://' o 'ftp://'.")
        if " " in texto:
            sugerencias.append("La URL no debe contener espacios.")
        if texto.count("//") == 0:
            sugerencias.append("Falta '://' después del protocolo.")
        if not sugerencias:
            sugerencias.append("Asegúrate de que el dominio tenga extensión válida (ej: .com, .org).")

    elif tipo == "fecha":
        sugerencias.append("Formatos aceptados: DD/MM/AAAA, AAAA-MM-DD, DD.MM.AAAA")
        partes = re.split(r"[/\-\.]", texto)
        if len(partes) != 3:
            sugerencias.append("La fecha debe tener exactamente 3 partes separadas por /, - o .")
        elif len(texto) < 8:
            sugerencias.append("Verifica que el año sea de 4 dígitos y el mes/día de 2 dígitos.")

    elif tipo == "contrasena":
        if len(texto) < 8:
            sugerencias.append(f"Muy corta. Tienes {len(texto)} caracteres, mínimo 8.")
        if not re.search(r"[A-Z]", texto):
            sugerencias.append("Falta al menos una letra MAYÚSCULA.")
        if not re.search(r"[a-z]", texto):
            sugerencias.append("Falta al menos una letra minúscula.")
        if not re.search(r"\d", texto):
            sugerencias.append("Falta al menos un número (0-9).")
        if not re.search(r"[!@#$%^&*()\-_=+\[\]{};':\"\\|,.<>/?]", texto):
            sugerencias.append("Falta al menos un carácter especial (!@#$%^&*...).")

    if not sugerencias:
        sugerencias.append("El texto no coincide con el patrón esperado.")

    return sugerencias


# ─────────────────────────────────────────────────────────────────
#  Formateo de resultado
# ─────────────────────────────────────────────────────────────────

def formatear_validacion(resultado: dict, texto_evaluado: str) -> str:
    estado = "✅ VÁLIDO" if resultado["valido"] else "❌ INVÁLIDO"
    out  = f"VALIDADOR: {resultado.get('nombre', '')}\n"
    out += "=" * 50 + "\n"
    out += f"TEXTO EVALUADO: '{texto_evaluado}'\n"
    out += f"RESULTADO: {estado}\n\n"
    out += f"EXPRESIÓN REGULAR:\n  {resultado['er']}\n\n"
    out += f"FORMATO ESPERADO: {resultado['descripcion']}\n\n"

    if not resultado["valido"] and resultado.get("sugerencias"):
        out += "SUGERENCIAS DE CORRECCIÓN:\n"
        for s in resultado["sugerencias"]:
            out += f"  • {s}\n"
        out += "\n"

    out += "EJEMPLOS VÁLIDOS:\n"
    for ej in resultado.get("ejemplos_validos", []):
        out += f"  ✔ {ej}\n"

    return out


# ─────────────────────────────────────────────────────────────────
#  AFD simplificado equivalente a la ER (para visualización didáctica)
# ─────────────────────────────────────────────────────────────────

AFD_EQUIVALENTES = {
    "email": {
        "descripcion": "AFD conceptual para correo electrónico",
        "estados": ["q0(usuario)", "q1(@)", "q2(dominio)", "q3(.)", "q4(extensión)"],
        "estado_inicial": "q0(usuario)",
        "estados_aceptacion": {"q4(extensión)"},
        "reglas": [
            "q0: Lee caracteres alfanuméricos/especiales del usuario",
            "q0 ──[@]──▶ q1",
            "q1: Lee caracteres del dominio",
            "q1 ──[.]──▶ q3",
            "q2 ──[.]──▶ q3",
            "q3: Lee extensión (2+ letras) ──▶ q4 (aceptación)",
        ],
    },
    "contrasena": {
        "descripcion": "AFD conceptual para contraseña segura",
        "estados": ["q0(inicio)", "q1(tiene_min)", "q2(+may)", "q3(+num)", "q4(+especial≥8)"],
        "estado_inicial": "q0(inicio)",
        "estados_aceptacion": {"q4(+especial≥8)"},
        "reglas": [
            "q0 ──[minúscula]──▶ q1",
            "q1 ──[MAYÚSCULA]──▶ q2",
            "q2 ──[0-9]──▶ q3",
            "q3 ──[!@#... y len≥8]──▶ q4 ✅",
        ],
    },
}


def obtener_afd_equivalente(tipo: str) -> str:
    """Retorna descripción textual del AFD equivalente a la ER."""
    if tipo not in AFD_EQUIVALENTES:
        return f"AFD equivalente para '{tipo}' no disponible en modo didáctico.\n"

    info = AFD_EQUIVALENTES[tipo]
    out  = f"AFD EQUIVALENTE (simplificado): {info['descripcion']}\n"
    out += "-" * 55 + "\n"
    out += f"Estados: {', '.join(info['estados'])}\n"
    out += f"Estado inicial: {info['estado_inicial']}\n"
    out += f"Estados de aceptación: {', '.join(info['estados_aceptacion'])}\n\n"
    out += "Reglas de transición:\n"
    for r in info["reglas"]:
        out += f"  {r}\n"
    return out
