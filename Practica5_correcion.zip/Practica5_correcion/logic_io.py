"""
logic_io.py — Importación/Exportación y Pruebas Múltiples
"""
import json
import os
import xml.etree.ElementTree as ET


# ─────────────────────────────────
#  EXPORTACIÓN
# ─────────────────────────────────

def exportar_json(automata: dict, ruta: str) -> str:
    """Exporta un autómata a JSON."""
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(automata, f, indent=2, ensure_ascii=False,
                  default=lambda x: list(x) if isinstance(x, (set, frozenset)) else x)
    return os.path.abspath(ruta)


def exportar_txt(automata: dict, ruta: str) -> str:
    """Exporta descripción textual de un autómata."""
    tipo = automata.get("tipo", "AFD")
    estados = automata.get("estados", [])
    simbolos = automata.get("simbolos", [])
    ei = automata.get("estado_inicial", "")
    ea = automata.get("estados_aceptacion", set())
    trans = automata.get("transiciones", {})

    lineas = [
        f"TIPO: {tipo}",
        f"ESTADOS: {', '.join(sorted(estados))}",
        f"ALFABETO: {', '.join(simbolos)}",
        f"ESTADO INICIAL: {ei}",
        f"ESTADOS DE ACEPTACIÓN: {', '.join(sorted(ea))}",
        "",
        "TABLA DE TRANSICIONES:",
    ]

    if tipo == "AFD":
        header = f"{'Estado':<15}" + "".join(f"{s:<12}" for s in simbolos)
        lineas.append(header)
        for estado, t in trans.items():
            fila = f"{estado:<15}" + "".join(f"{t.get(s,'∅'):<12}" for s in simbolos)
            lineas.append(fila)
    else:
        # AFND/AFN-λ: las transiciones pueden ser conjuntos
        header = f"{'Estado':<15}" + "".join(f"{s:<18}" for s in simbolos)
        lineas.append(header)
        for estado, t in trans.items():
            fila = f"{estado:<15}"
            for s in simbolos:
                dest = t.get(s, set())
                if isinstance(dest, (set, list, frozenset)):
                    dest_str = "{" + ",".join(sorted(dest)) + "}" if dest else "∅"
                else:
                    dest_str = str(dest) if dest else "∅"
                fila += f"{dest_str:<18}"
            lineas.append(fila)

    with open(ruta, "w", encoding="utf-8") as f:
        f.write("\n".join(lineas))
    return os.path.abspath(ruta)


def exportar_jff(automata: dict, ruta: str) -> str:
    """
    Exporta en formato JFF (JFLAP).
    Solo soporta AFD y AFND (sin lambda para simplificar).
    """
    root = ET.Element("structure")
    ET.SubElement(root, "type").text = "fa"
    automaton = ET.SubElement(root, "automaton")

    estados = automata.get("estados", [])
    ei      = automata.get("estado_inicial", "")
    ea      = automata.get("estados_aceptacion", set())

    id_map = {e: str(i) for i, e in enumerate(estados)}

    for estado in estados:
        s = ET.SubElement(automaton, "state",
                          id=id_map[estado], name=estado)
        if estado == ei:
            ET.SubElement(s, "initial")
        if estado in ea:
            ET.SubElement(s, "final")

    trans = automata.get("transiciones", {})
    for estado, t in trans.items():
        for sym, dest in t.items():
            dests = dest if isinstance(dest, (set, list, frozenset)) else {dest}
            for d in dests:
                tr = ET.SubElement(automaton, "transition")
                ET.SubElement(tr, "from").text = id_map.get(estado, estado)
                ET.SubElement(tr, "to").text   = id_map.get(d, d)
                ET.SubElement(tr, "read").text  = sym if sym != "λ" else ""

    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")
    tree.write(ruta, encoding="utf-8", xml_declaration=True)
    return os.path.abspath(ruta)


# ─────────────────────────────────
#  IMPORTACIÓN
# ─────────────────────────────────

def importar_json(ruta: str) -> dict:
    """Importa un autómata desde JSON."""
    with open(ruta, "r", encoding="utf-8") as f:
        data = json.load(f)
    # Normalizar conjuntos
    if "estados_aceptacion" in data:
        data["estados_aceptacion"] = set(data["estados_aceptacion"])
    return data


def importar_jff(ruta: str) -> dict:
    """
    Importa un autómata desde archivo JFF (JFLAP).
    Retorna dict con estructura de autómata.
    """
    tree = ET.parse(ruta)
    root = tree.getroot()
    automaton = root.find("automaton")

    estados  = []
    ei       = None
    ea       = set()
    id_name  = {}

    for state in automaton.findall("state"):
        sid  = state.get("id")
        name = state.get("name")
        id_name[sid] = name
        estados.append(name)
        if state.find("initial") is not None:
            ei = name
        if state.find("final") is not None:
            ea.add(name)

    trans_nd: dict = {}
    simbolos: set  = set()

    for tr in automaton.findall("transition"):
        src  = id_name.get(tr.find("from").text, tr.find("from").text)
        dst  = id_name.get(tr.find("to").text, tr.find("to").text)
        read = tr.find("read").text or "λ"
        simbolos.add(read)
        trans_nd.setdefault(src, {}).setdefault(read, set()).add(dst)

    tipo = "AFND"
    if "λ" in simbolos:
        tipo = "AFN-λ"
        simbolos.discard("λ")

    return {
        "tipo": tipo,
        "estados": estados,
        "simbolos": sorted(simbolos),
        "estado_inicial": ei,
        "estados_aceptacion": ea,
        "transiciones": trans_nd,
    }


# ─────────────────────────────────
#  PRUEBAS MÚLTIPLES
# ─────────────────────────────────

def pruebas_multiples_afd(transiciones, estado_inicial, estados_aceptacion,
                           cadenas: list, simular_fn) -> list:
    """Ejecuta varias cadenas contra un autómata y retorna resultados."""
    resultados = []
    for cadena in cadenas:
        r = simular_fn(transiciones, estado_inicial, estados_aceptacion, cadena)
        resultados.append({
            "cadena": cadena,
            "aceptada": r["aceptada"],
        })
    return resultados


def formatear_pruebas_multiples(resultados: list, tipo: str = "AFD") -> str:
    texto  = f"PRUEBAS MÚLTIPLES — {tipo}\n"
    texto += "=" * 40 + "\n"
    texto += f"{'Cadena':<25} {'Resultado'}\n"
    texto += "-" * 40 + "\n"
    for r in resultados:
        cad = f"'{r['cadena']}'" if r["cadena"] else "'ε (vacía)'"
        res = "✅ ACEPTADA" if r["aceptada"] else "❌ RECHAZADA"
        texto += f"{cad:<25} {res}\n"
    aceptadas  = sum(1 for r in resultados if r["aceptada"])
    rechazadas = len(resultados) - aceptadas
    texto += "-" * 40 + "\n"
    texto += f"Total: {len(resultados)}  |  Aceptadas: {aceptadas}  |  Rechazadas: {rechazadas}\n"
    return texto
