"""
logic_minimizacion.py — Minimización de AFD (algoritmo de Hopcroft / clases de equivalencia)
"""


def minimizar_afd(transiciones: dict, estado_inicial: str,
                  estados_aceptacion: set, simbolos: list) -> dict:
    """
    Minimiza un AFD usando el algoritmo de tabla de distinguibilidad (Myhill-Nerode).
    Retorna el AFD mínimo con el proceso detallado.
    """
    todos_estados = list(transiciones.keys())

    # 1. Eliminar estados inaccesibles
    accesibles = _estados_accesibles(transiciones, estado_inicial)
    estados_acc = [e for e in todos_estados if e in accesibles]
    inaccesibles = [e for e in todos_estados if e not in accesibles]

    # Filtrar a solo accesibles
    trans_acc = {e: transiciones[e] for e in estados_acc}
    acept_acc = estados_aceptacion & accesibles

    # 2. Tabla de distinguibilidad
    tabla_dist, pasos_marcado = _tabla_distinguibilidad(
        estados_acc, trans_acc, acept_acc, simbolos
    )

    # 3. Construir clases de equivalencia
    clases = _construir_clases(estados_acc, tabla_dist)

    # 4. Construir AFD mínimo
    afd_min = _construir_afd_minimo(
        clases, trans_acc, estado_inicial, acept_acc, simbolos
    )

    return {
        "estados_originales": todos_estados,
        "estados_accesibles": estados_acc,
        "estados_inaccesibles": inaccesibles,
        "tabla_distinguibilidad": tabla_dist,
        "pasos_marcado": pasos_marcado,
        "clases_equivalencia": clases,
        "afd_minimo": afd_min,
        "reduccion": len(todos_estados) - len(afd_min["estados"]),
    }


def formatear_minimizacion(resultado: dict) -> str:
    texto  = "MINIMIZACIÓN DE AFD (Algoritmo de Hopcroft)\n"
    texto += "=" * 50 + "\n\n"

    texto += f"Estados originales ({len(resultado['estados_originales'])}): "
    texto += ", ".join(sorted(resultado["estados_originales"])) + "\n"

    if resultado["estados_inaccesibles"]:
        texto += f"Estados inaccesibles eliminados: "
        texto += ", ".join(sorted(resultado["estados_inaccesibles"])) + "\n"
    else:
        texto += "Sin estados inaccesibles.\n"

    texto += "\n─── CLASES DE EQUIVALENCIA ───\n"
    for i, clase in enumerate(resultado["clases_equivalencia"]):
        texto += f"  Clase {i}: {{{', '.join(sorted(clase))}}}\n"

    afd_min = resultado["afd_minimo"]
    texto += "\n─── AFD MÍNIMO RESULTANTE ───\n"
    simbolos = afd_min["simbolos"]
    texto += f"{'Estado':<20}" + "".join(f"{s:<12}" for s in simbolos) + "\n"
    texto += "-" * (20 + 12 * len(simbolos)) + "\n"

    for estado, trans in afd_min["transiciones"].items():
        marcador = "→" if estado == afd_min["estado_inicial"] else " "
        marcador += "*" if estado in afd_min["estados_aceptacion"] else " "
        fila = f"{marcador} {estado:<18}"
        for sym in simbolos:
            fila += f"{trans.get(sym, '∅'):<12}"
        texto += fila + "\n"

    texto += f"\nESTADOS TOTALES: {len(resultado['estados_originales'])} → {len(afd_min['estados'])}"
    texto += f" (reducción de {resultado['reduccion']} estados)\n"
    texto += f"ESTADO INICIAL: {afd_min['estado_inicial']}\n"
    texto += f"ESTADOS DE ACEPTACIÓN: {{{', '.join(sorted(afd_min['estados_aceptacion']))}}}\n"
    return texto


# ─────────────────────────────────
#  Helpers internos
# ─────────────────────────────────

def _estados_accesibles(transiciones: dict, inicial: str) -> set:
    visitados = set()
    cola = [inicial]
    while cola:
        actual = cola.pop()
        if actual in visitados:
            continue
        visitados.add(actual)
        for dest in transiciones.get(actual, {}).values():
            if dest and dest not in visitados:
                cola.append(dest)
    return visitados


def _tabla_distinguibilidad(estados: list, transiciones: dict,
                             aceptacion: set, simbolos: list):
    """
    Construye la tabla de pares distinguibles.
    Retorna (tabla_dist_set, lista_de_pasos).
    """
    n = len(estados)
    idx = {e: i for i, e in enumerate(estados)}
    # distinguible[i][j] = True si el par (estados[i], estados[j]) es distinguible
    distinguible = [[False] * n for _ in range(n)]
    pasos = []

    # Paso base: marcar pares (aceptación, no-aceptación)
    for i in range(n):
        for j in range(i + 1, n):
            ei, ej = estados[i], estados[j]
            if (ei in aceptacion) != (ej in aceptacion):
                distinguible[i][j] = True
                pasos.append(f"Base: ({ei}, {ej}) distinguibles (uno acepta, otro no)")

    # Iteración
    cambio = True
    while cambio:
        cambio = False
        for i in range(n):
            for j in range(i + 1, n):
                if distinguible[i][j]:
                    continue
                ei, ej = estados[i], estados[j]
                for sym in simbolos:
                    di = transiciones.get(ei, {}).get(sym, None)
                    dj = transiciones.get(ej, {}).get(sym, None)
                    if di is None or dj is None:
                        continue
                    if di == dj:
                        continue
                    ki = idx.get(di, -1)
                    kj = idx.get(dj, -1)
                    if ki == -1 or kj == -1:
                        continue
                    lo, hi = (ki, kj) if ki < kj else (kj, ki)
                    if distinguible[lo][hi]:
                        distinguible[i][j] = True
                        pasos.append(f"Iter: ({ei},{ej}) distinguibles vía '{sym}' → ({di},{dj})")
                        cambio = True
                        break

    # Construir conjunto de pares distinguibles
    dist_set = set()
    for i in range(n):
        for j in range(i + 1, n):
            if distinguible[i][j]:
                dist_set.add((estados[i], estados[j]))

    return dist_set, pasos


def _construir_clases(estados: list, dist_set: set) -> list:
    """Agrupa estados indistinguibles en clases."""
    n = len(estados)
    padre = list(range(n))

    def find(x):
        while padre[x] != x:
            padre[x] = padre[padre[x]]
            x = padre[x]
        return x

    def union(x, y):
        px, py = find(x), find(y)
        if px != py:
            padre[px] = py

    for i in range(n):
        for j in range(i + 1, n):
            if (estados[i], estados[j]) not in dist_set and \
               (estados[j], estados[i]) not in dist_set:
                union(i, j)

    clases_dict: dict = {}
    for i, e in enumerate(estados):
        root = find(i)
        clases_dict.setdefault(root, set()).add(e)

    return list(clases_dict.values())


def _construir_afd_minimo(clases: list, transiciones: dict,
                           estado_inicial: str, estados_aceptacion: set,
                           simbolos: list) -> dict:
    """Construye el AFD mínimo a partir de las clases de equivalencia."""
    # Nombre de cada clase = representante ordenado
    rep = {e: _nombre_clase(c) for c in clases for e in c}

    trans_min = {}
    acept_min = set()
    ei_min    = rep[estado_inicial]

    for clase in clases:
        nombre = _nombre_clase(clase)
        trans_min[nombre] = {}
        # Tomar cualquier representante
        repr_estado = next(iter(sorted(clase)))
        for sym in simbolos:
            dest = transiciones.get(repr_estado, {}).get(sym, None)
            trans_min[nombre][sym] = rep.get(dest, "∅") if dest else "∅"
        if clase & estados_aceptacion:
            acept_min.add(nombre)

    return {
        "transiciones": trans_min,
        "estado_inicial": ei_min,
        "estados_aceptacion": acept_min,
        "estados": list(trans_min.keys()),
        "simbolos": simbolos,
    }


def _nombre_clase(clase: set) -> str:
    return "{" + ",".join(sorted(clase)) + "}"
