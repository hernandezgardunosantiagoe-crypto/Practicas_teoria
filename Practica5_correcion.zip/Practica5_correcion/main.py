"""
main.py — App principal compatible con Flet 0.84.0

Secciones:
  0  Cadenas       — Subcadenas, prefijos, sufijos, cerraduras
  1  AFD           — Simulador de Autómata Finito Determinista
  2  AFND          — Simulador No Determinista
  3  AFN-λ         — Simulador con transiciones lambda
  4  Conversiones  — AFND→AFD y AFN-λ→AFND
  5  Minimización  — Algoritmo de Hopcroft
  6  I/O & Pruebas — Importar/Exportar y pruebas múltiples
  7  AFD → ER      — Conversión a Expresión Regular (Ejercicio 2)
  8  Validadores   — Validadores con Expresiones Regulares (Ejercicio 3)
  9  Visualización — Grafo interactivo del autómata (NUEVO)
"""

import flet as ft
import itertools
import os
import ssl

ssl._create_default_https_context = ssl._create_unverified_context
os.environ.setdefault("FLET_SECRET_KEY", "local")

from logic_afd        import simular_AFD, formatear_resultado_automata
from ui_shared        import abrir_ventana_resultado, mostrar_snack, guardar_archivo
from ui_afnd_afnl     import seccion_afnd, seccion_afnl
from ui_conversion    import seccion_conversion_afnd_afd, seccion_eliminacion_lambda
from ui_minimizacion  import seccion_minimizacion
from ui_io            import seccion_io_pruebas
from ui_afd_to_er     import seccion_afd_to_er
from ui_er_validator  import seccion_er_validadores
from ui_visualizacion import seccion_visualizacion   # ← NUEVO


# ════════════════════════════════════════════════════════════════
#  LÓGICA ORIGINAL (cadenas / cerraduras)
# ════════════════════════════════════════════════════════════════

def calcular_subcadenas(cadena: str) -> dict:
    n = len(cadena)
    subcadenas = [cadena[i:j] for i in range(n) for j in range(i + 1, n + 1)]
    prefijos   = [cadena[:i] for i in range(1, n + 1)]
    sufijos    = [cadena[i:] for i in range(n)]
    return {"cadena": cadena, "subcadenas": subcadenas,
            "prefijos": prefijos, "sufijos": sufijos}


def formatear_subcadenas(datos: dict) -> str:
    cadena = datos["cadena"]
    texto  = f"CADENA: '{cadena}'\n\n"
    texto += f"SUBCADENAS ({len(datos['subcadenas'])}):\n"
    texto += ", ".join(f"'{s}'" for s in datos["subcadenas"]) + "\n\n"
    texto += f"PREFIJOS ({len(datos['prefijos'])}):\n"
    texto += ", ".join(f"'{p}'" for p in datos["prefijos"]) + "\n\n"
    texto += f"SUFIJOS ({len(datos['sufijos'])}):\n"
    texto += ", ".join(f"'{s}'" for s in datos["sufijos"])
    return texto


def calcular_cerraduras(alfabeto: list, max_len: int) -> dict:
    kleene   = [""]
    positiva = []
    for i in range(1, max_len + 1):
        for combo in itertools.product(alfabeto, repeat=i):
            cadena = "".join(combo)
            kleene.append(cadena)
            positiva.append(cadena)
    return {"alfabeto": alfabeto, "max_len": max_len,
            "kleene": kleene, "positiva": positiva}


def formatear_cerraduras(datos: dict) -> str:
    alfabeto = datos["alfabeto"]
    max_len  = datos["max_len"]
    texto    = f"ALFABETO: {{{', '.join(alfabeto)}}}\n"
    texto   += f"LONGITUD MÁXIMA: {max_len}\n\n"
    texto   += f"CERRADURA DE KLEENE (*) — {len(datos['kleene'])} cadenas:\n"
    for i in range(max_len + 1):
        if i == 0:
            cadenas = ["ε (cadena vacía)"]
        else:
            cadenas = ["".join(p) for p in itertools.product(alfabeto, repeat=i)]
        texto += f"  Longitud {i}: " + ", ".join(f"'{c}'" for c in cadenas) + "\n"
    texto += f"\nCERRADURA POSITIVA (+) — {len(datos['positiva'])} cadenas:\n"
    for i in range(1, max_len + 1):
        cadenas = ["".join(p) for p in itertools.product(alfabeto, repeat=i)]
        texto += f"  Longitud {i}: " + ", ".join(f"'{c}'" for c in cadenas) + "\n"
    return texto


# ════════════════════════════════════════════════════════════════
#  SECCIONES UI ORIGINALES
# ════════════════════════════════════════════════════════════════

def seccion_subcadenas(page: ft.Page) -> ft.Column:
    campo_cadena = ft.TextField(label="Ingrese una cadena",
                                hint_text="Ejemplo: hola", width=400)

    def on_calcular(e):
        cadena = campo_cadena.value.strip()
        if not cadena:
            mostrar_snack(page, "Por favor, ingrese una cadena.")
            return
        datos = calcular_subcadenas(cadena)
        texto = formatear_subcadenas(datos)
        abrir_ventana_resultado(page, "Subcadenas, Prefijos y Sufijos",
                                texto, None, "resultados_subcadenas.txt")

    return ft.Column([
        ft.Text("1. Subcadenas, Prefijos y Sufijos",
                size=20, weight=ft.FontWeight.BOLD),
        campo_cadena,
        ft.ElevatedButton("Calcular", on_click=on_calcular),
    ], spacing=12)


def seccion_cerraduras(page: ft.Page) -> ft.Column:
    campo_alfabeto = ft.TextField(label="Alfabeto (separado por comas)",
                                  hint_text="Ejemplo: a,b,c", width=400)
    campo_longitud = ft.TextField(label="Longitud máxima", hint_text="Ejemplo: 3",
                                  width=180, value="3",
                                  keyboard_type=ft.KeyboardType.NUMBER)

    def on_calcular(e):
        alfabeto_str = campo_alfabeto.value.strip()
        if not alfabeto_str:
            mostrar_snack(page, "Por favor, ingrese un alfabeto.")
            return
        try:
            max_len = int(campo_longitud.value)
            if max_len < 1:
                raise ValueError
        except ValueError:
            mostrar_snack(page, "La longitud máxima debe ser un entero >= 1.")
            return
        alfabeto = [s.strip() for s in alfabeto_str.split(",") if s.strip()]
        if not alfabeto:
            mostrar_snack(page, "El alfabeto no puede estar vacío.")
            return
        datos = calcular_cerraduras(alfabeto, max_len)
        texto = formatear_cerraduras(datos)
        abrir_ventana_resultado(page, "Cerradura de Kleene y Positiva",
                                texto, None, "resultados_cerraduras.txt")

    return ft.Column([
        ft.Text("2. Cerradura de Kleene (*) y Positiva (+)",
                size=20, weight=ft.FontWeight.BOLD),
        ft.Row([campo_alfabeto, campo_longitud]),
        ft.ElevatedButton("Calcular", on_click=on_calcular),
    ], spacing=12)


def seccion_automata(page: ft.Page) -> ft.Column:
    estados  = ["q0", "q1"]
    simbolos = ["a", "b"]
    tabla_container = ft.Column(scroll=ft.ScrollMode.AUTO)
    campo_estado_inicial = ft.TextField(label="Estado inicial", value="q0", width=150)
    campo_estados_acept  = ft.TextField(
        label="Estados de aceptación (separados por comas)",
        hint_text="Ejemplo: q1, q2", width=300)
    campo_cadena = ft.TextField(label="Cadena a evaluar",
                                hint_text="Ejemplo: ab", width=300)
    celdas: dict = {}

    def reconstruir_tabla():
        celdas.clear()
        tabla_container.controls.clear()
        encabezado = ft.Row([
            ft.Container(content=ft.Text("δ", weight=ft.FontWeight.BOLD,
                         text_align=ft.TextAlign.CENTER),
                         width=90, bgcolor="#E0E0E0", padding=5),
        ] + [
            ft.Container(content=ft.Text(s, weight=ft.FontWeight.BOLD,
                         text_align=ft.TextAlign.CENTER),
                         width=110, bgcolor="#E0E0E0", padding=5)
            for s in simbolos
        ])
        tabla_container.controls.append(encabezado)
        for i, estado in enumerate(estados):
            fila_celdas = []
            for j in range(len(simbolos)):
                tf = ft.TextField(hint_text="q?", width=100, height=45, text_size=12)
                celdas[(i, j)] = tf
                fila_celdas.append(tf)
            tabla_container.controls.append(ft.Row([
                ft.Container(content=ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
            ] + fila_celdas))
        page.update()

    def agregar_estado(e): estados.append(f"q{len(estados)}"); reconstruir_tabla()
    def quitar_estado(e):
        if len(estados) > 1: estados.pop(); reconstruir_tabla()
    def agregar_simbolo(e):
        letras = "abcdefghijklmnopqrstuvwxyz0123456789"
        nuevo = letras[len(simbolos)] if len(simbolos) < len(letras) else str(len(simbolos))
        simbolos.append(nuevo); reconstruir_tabla()
    def quitar_simbolo(e):
        if len(simbolos) > 1: simbolos.pop(); reconstruir_tabla()

    def on_determinar(e):
        ei = campo_estado_inicial.value.strip()
        if not ei:
            mostrar_snack(page, "Ingresa el estado inicial.")
            return
        ea_str = campo_estados_acept.value.strip()
        if not ea_str:
            mostrar_snack(page, "Ingresa al menos un estado de aceptación.")
            return
        estados_acept = {s.strip() for s in ea_str.split(",") if s.strip()}
        cadena = campo_cadena.value
        transiciones: dict = {}
        for i, estado in enumerate(estados):
            transiciones[estado] = {}
            for j, simbolo in enumerate(simbolos):
                valor = celdas.get((i, j))
                val_str = valor.value.strip() if valor and valor.value else ""
                if val_str:
                    transiciones[estado][simbolo] = val_str
        resultado = simular_AFD(transiciones, ei, estados_acept, cadena)
        texto = formatear_resultado_automata(resultado, cadena, ei, estados_acept)
        abrir_ventana_resultado(page, "Simulación AFD", texto,
                                resultado["aceptada"], "resultados_automata.txt")

    reconstruir_tabla()

    return ft.Column([
        ft.Text("3. Simulador AFD", size=20, weight=ft.FontWeight.BOLD),
        ft.Text("Tabla de transición δ:", weight=ft.FontWeight.W_600),
        ft.Row([
            ft.ElevatedButton("+ Estado",  on_click=agregar_estado),
            ft.ElevatedButton("- Estado",  on_click=quitar_estado),
            ft.ElevatedButton("+ Símbolo", on_click=agregar_simbolo),
            ft.ElevatedButton("- Símbolo", on_click=quitar_simbolo),
        ], spacing=8),
        ft.Container(content=tabla_container,
                     border=ft.border.all(1, "#BDBDBD"),
                     border_radius=8, padding=10),
        ft.Row([campo_estado_inicial, campo_estados_acept], spacing=12),
        campo_cadena,
        ft.ElevatedButton("Determinar", on_click=on_determinar),
    ], spacing=12)


# ════════════════════════════════════════════════════════════════
#  APP PRINCIPAL — navegación manual con Stack (compatible 0.84)
# ════════════════════════════════════════════════════════════════

SECCIONES = [
    "Cadenas",          # 0
    "AFD",              # 1
    "AFND",             # 2
    "AFN-λ",            # 3
    "Conversiones",     # 4
    "Minimización",     # 5
    "I/O & Pruebas",    # 6
    "AFD → ER",         # 7
    "Validadores ER",   # 8
    "🎨 Visualización", # 9  ← NUEVO
]

_COLOR_VIS   = ("#1A237E", "#E8EAF6")
_COLOR_NUEVO = ("#4A148C", "#EDE7F6")
_COLOR_BASE  = ("#1565C0", None)


def _color_boton(indice: int, seleccionado: bool):
    if indice == 9:
        activo, inactivo_bg = _COLOR_VIS
    elif indice >= 7:
        activo, inactivo_bg = _COLOR_NUEVO
    else:
        activo, inactivo_bg = _COLOR_BASE

    if seleccionado:
        return activo, "white"
    return inactivo_bg, (activo if inactivo_bg else None)


class App:
    def main(self, page: ft.Page):
        page.title = "Operaciones con Cadenas, Alfabetos y Autómatas"
        page.theme_mode = ft.ThemeMode.LIGHT
        page.padding = 0
        page.scroll = ft.ScrollMode.HIDDEN

        idx_actual = {"v": 0}

        # ── Contenidos de cada sección ──────────────────────────
        contenidos = [
            # 0: Cadenas
            ft.Column([
                seccion_subcadenas(page),
                ft.Divider(height=30),
                seccion_cerraduras(page),
            ], spacing=0, scroll=ft.ScrollMode.AUTO),

            # 1: AFD
            ft.Column([seccion_automata(page)],
                      scroll=ft.ScrollMode.AUTO),

            # 2: AFND
            ft.Column([seccion_afnd(page)],
                      scroll=ft.ScrollMode.AUTO),

            # 3: AFN-λ
            ft.Column([seccion_afnl(page)],
                      scroll=ft.ScrollMode.AUTO),

            # 4: Conversiones
            ft.Column([
                seccion_conversion_afnd_afd(page),
                ft.Divider(height=30),
                seccion_eliminacion_lambda(page),
            ], spacing=0, scroll=ft.ScrollMode.AUTO),

            # 5: Minimización
            ft.Column([seccion_minimizacion(page)],
                      scroll=ft.ScrollMode.AUTO),

            # 6: I/O & Pruebas
            ft.Column([seccion_io_pruebas(page)],
                      scroll=ft.ScrollMode.AUTO),

            # 7: AFD → ER
            ft.Column([seccion_afd_to_er(page)],
                      scroll=ft.ScrollMode.AUTO),

            # 8: Validadores ER
            ft.Column([seccion_er_validadores(page)],
                      scroll=ft.ScrollMode.AUTO),

            # 9: Visualización gráfica ← NUEVO
            ft.Column([seccion_visualizacion(page)],
                      scroll=ft.ScrollMode.AUTO),
        ]

        # Envolver cada contenido en Container con padding
        vistas = [
            ft.Container(
                content=c,
                padding=ft.padding.all(24),
                expand=True,
                visible=(i == 0),
            )
            for i, c in enumerate(contenidos)
        ]

        # ── Botones de navegación ───────────────────────────────
        botones_nav = []

        def hacer_on_click(indice):
            def on_click(e):
                vistas[idx_actual["v"]].visible = False
                idx_actual["v"] = indice
                vistas[indice].visible = True
                for i, btn in enumerate(botones_nav):
                    bg, fg = _color_boton(i, i == indice)
                    btn.style = ft.ButtonStyle(bgcolor=bg, color=fg)
                page.update()
            return on_click

        for i, nombre in enumerate(SECCIONES):
            bg, fg = _color_boton(i, i == 0)
            btn = ft.ElevatedButton(
                nombre,
                on_click=hacer_on_click(i),
                style=ft.ButtonStyle(bgcolor=bg, color=fg),
            )
            botones_nav.append(btn)

        barra_nav = ft.Container(
            content=ft.Row(
                botones_nav,
                spacing=4,
                scroll=ft.ScrollMode.AUTO,
            ),
            bgcolor="#F5F5F5",
            padding=ft.padding.symmetric(horizontal=12, vertical=8),
            border=ft.border.only(bottom=ft.BorderSide(1, "#DDDDDD")),
        )

        stack_vistas = ft.Stack(vistas, expand=True)

        page.add(
            ft.Column([
                barra_nav,
                stack_vistas,
            ], spacing=0, expand=True)
        )


def main():
    ft.app(target=App().main)


if __name__ == "__main__":
    main()