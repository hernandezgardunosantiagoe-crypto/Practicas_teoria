"""
ui_afd_to_er.py — UI para Conversión AFD → ER (Ejercicio 2, Flet 0.84.0)

Funcionalidades:
  - Crear/editar AFD mediante interfaz gráfica (tabla de transiciones)
  - Importar desde archivo .jff (JFLAP)
  - Validar que sea un AFD válido
  - Ejecutar algoritmo de eliminación de estados paso a paso
  - Visualizar la ER resultante de forma clara
"""
import flet as ft
from logic_afd_to_er import afd_a_er, formatear_afd_a_er, validar_afd
from logic_io import importar_jff, importar_json
from ui_shared import abrir_ventana_resultado, mostrar_snack


def seccion_afd_to_er(page: ft.Page) -> ft.Column:
    # ── Estado mutable ──────────────────────────────────────────
    estados  = ["q0", "q1", "q2"]
    simbolos = ["a", "b"]
    celdas: dict = {}

    # ── Controles principales ────────────────────────────────────
    tabla_container = ft.Column(scroll=ft.ScrollMode.AUTO)
    campo_ei = ft.TextField(label="Estado inicial", value="q0", width=150)
    campo_ea = ft.TextField(
        label="Estados de aceptación (comas)",
        hint_text="Ej: q2", width=280,
    )

    # Panel de resultado visible en pantalla
    er_resultado_text = ft.Text(
        value="",
        size=18,
        weight=ft.FontWeight.BOLD,
        color="#1B5E20",
        selectable=True,
        visible=False,
    )
    er_resultado_card = ft.Container(
        content=ft.Column([
            ft.Text("Expresión Regular resultante:",
                    weight=ft.FontWeight.W_600, color="#555555"),
            er_resultado_text,
        ]),
        bgcolor="#F1F8E9",
        border=ft.border.all(2, "#66BB6A"),
        border_radius=10,
        padding=16,
        visible=False,
    )

    # Indicador de validez
    validez_label = ft.Text("", size=13, italic=True)

    # Importación por ruta de archivo
    campo_ruta_import = ft.TextField(
        label="Ruta de archivo .jff o .json a importar",
        hint_text=r"Ej: automata.jff",
        width=480,
    )

    # ── Tabla de transiciones ────────────────────────────────────

    def reconstruir_tabla():
        celdas.clear()
        tabla_container.controls.clear()

        encabezado = ft.Row([
            ft.Container(ft.Text("δ", weight=ft.FontWeight.BOLD,
                                 text_align=ft.TextAlign.CENTER),
                         width=90, bgcolor="#E8EAF6", padding=5),
        ] + [
            ft.Container(ft.Text(s, weight=ft.FontWeight.BOLD,
                                 text_align=ft.TextAlign.CENTER),
                         width=110, bgcolor="#E8EAF6", padding=5)
            for s in simbolos
        ])
        tabla_container.controls.append(encabezado)

        for i, estado in enumerate(estados):
            fila = []
            for j in range(len(simbolos)):
                tf = ft.TextField(hint_text="q?", width=100, height=45, text_size=12)
                celdas[(i, j)] = tf
                fila.append(tf)
            tabla_container.controls.append(ft.Row([
                ft.Container(ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
            ] + fila))
        page.update()

    # ── Gestión de estados y símbolos ────────────────────────────

    def agregar_estado(e):
        estados.append(f"q{len(estados)}")
        reconstruir_tabla()

    def quitar_estado(e):
        if len(estados) > 1:
            estados.pop()
            reconstruir_tabla()

    def agregar_simbolo(e):
        letras = "abcdefghijklmnopqrstuvwxyz"
        nuevo = letras[len(simbolos)] if len(simbolos) < len(letras) else str(len(simbolos))
        simbolos.append(nuevo)
        reconstruir_tabla()

    def quitar_simbolo(e):
        if len(simbolos) > 1:
            simbolos.pop()
            reconstruir_tabla()

    # ── Parseo de la tabla ───────────────────────────────────────

    def _parse_transiciones() -> dict:
        trans = {}
        for i, estado in enumerate(estados):
            trans[estado] = {}
            for j, sym in enumerate(simbolos):
                tf = celdas.get((i, j))
                val = tf.value.strip() if tf and tf.value else ""
                if val:
                    trans[estado][sym] = val
        return trans

    # ── Importación ──────────────────────────────────────────────

    def _cargar_afd_en_tabla(data: dict):
        """Carga un autómata importado en la interfaz."""
        nonlocal estados, simbolos

        tipo = data.get("tipo", "AFD")
        if tipo not in ("AFD", "AFND"):
            mostrar_snack(page, f"El archivo contiene un {tipo}. Se necesita un AFD.")
            return

        estados.clear()
        simbolos.clear()
        estados.extend(data.get("estados", ["q0"]))
        simbolos.extend(data.get("simbolos", ["a"]))

        campo_ei.value = data.get("estado_inicial", "q0")
        ea_set = data.get("estados_aceptacion", set())
        campo_ea.value = ", ".join(sorted(ea_set))

        reconstruir_tabla()

        # Rellenar celdas con las transiciones
        trans = data.get("transiciones", {})
        for i, estado in enumerate(estados):
            for j, sym in enumerate(simbolos):
                dest = trans.get(estado, {}).get(sym, "")
                if isinstance(dest, (set, list, frozenset)):
                    dest = ", ".join(sorted(dest))
                tf = celdas.get((i, j))
                if tf:
                    tf.value = dest
        page.update()
        mostrar_snack(page, f"✅ AFD importado: {len(estados)} estados, {len(simbolos)} símbolos.")

    def on_importar(e):
        ruta = campo_ruta_import.value.strip()
        if not ruta:
            mostrar_snack(page, "Ingresa la ruta del archivo.")
            return
        try:
            if ruta.lower().endswith(".jff") or ruta.lower().endswith(".xml"):
                data = importar_jff(ruta)
            elif ruta.lower().endswith(".json"):
                data = importar_json(ruta)
            else:
                mostrar_snack(page, "Usa archivos .jff o .json")
                return
            _cargar_afd_en_tabla(data)
        except FileNotFoundError:
            mostrar_snack(page, f"❌ Archivo no encontrado: {ruta}")
        except Exception as ex:
            mostrar_snack(page, f"❌ Error al importar: {ex}")

    # ── Validación ───────────────────────────────────────────────

    def on_validar(e):
        ei = campo_ei.value.strip()
        ea_str = campo_ea.value.strip()
        ea = {s.strip() for s in ea_str.split(",") if s.strip()}
        trans = _parse_transiciones()
        ok, msg = validar_afd(trans, ei, ea, simbolos)
        validez_label.value = msg
        validez_label.color = "#1B5E20" if ok else "#B71C1C"
        page.update()

    # ── Conversión AFD → ER ──────────────────────────────────────

    def on_convertir(e):
        ei = campo_ei.value.strip()
        ea_str = campo_ea.value.strip()
        if not ei or not ea_str:
            mostrar_snack(page, "Completa el estado inicial y estados de aceptación.")
            return

        ea = {s.strip() for s in ea_str.split(",") if s.strip()}
        trans = _parse_transiciones()

        # Validar antes de convertir
        ok, msg = validar_afd(trans, ei, ea, simbolos)
        validez_label.value = msg
        validez_label.color = "#1B5E20" if ok else "#B71C1C"
        page.update()

        if not ok:
            mostrar_snack(page, f"AFD inválido: {msg}")
            return

        try:
            resultado = afd_a_er(trans, ei, ea)
            texto_completo = formatear_afd_a_er(resultado)

            # Mostrar ER en pantalla
            er_resultado_text.value = resultado["er"]
            er_resultado_text.visible = True
            er_resultado_card.visible = True
            page.update()

            # Abrir ventana con proceso completo
            abrir_ventana_resultado(
                page,
                "AFD → Expresión Regular (Eliminación de Estados)",
                texto_completo,
                None,
                "conversion_afd_er.txt",
            )
        except Exception as ex:
            mostrar_snack(page, f"❌ Error en conversión: {ex}")

    # ── Inicializar tabla ────────────────────────────────────────
    reconstruir_tabla()

    # ── Layout ──────────────────────────────────────────────────
    return ft.Column([
        ft.Text("10. Conversión AFD → Expresión Regular",
                size=20, weight=ft.FontWeight.BOLD, color="#283593"),
        ft.Text(
            "Implementa el algoritmo de Eliminación de Estados (GNFA).\n"
            "Puedes crear el AFD manualmente o importarlo desde un archivo .jff / .json.",
            size=13, color="#555555",
        ),

        ft.Divider(height=10),

        # Importación
        ft.Text("📂 Importar AFD desde archivo:", weight=ft.FontWeight.W_600),
        ft.Row([campo_ruta_import, ft.ElevatedButton("Importar", on_click=on_importar)]),

        ft.Divider(height=10),

        # Tabla manual
        ft.Text("✏️ Definir AFD manualmente:", weight=ft.FontWeight.W_600),
        ft.Row([
            ft.ElevatedButton("+ Estado",  on_click=agregar_estado),
            ft.ElevatedButton("- Estado",  on_click=quitar_estado),
            ft.ElevatedButton("+ Símbolo", on_click=agregar_simbolo),
            ft.ElevatedButton("- Símbolo", on_click=quitar_simbolo),
        ], spacing=8),
        ft.Container(
            content=tabla_container,
            border=ft.border.all(1, "#9FA8DA"),
            border_radius=8,
            padding=10,
        ),

        ft.Row([campo_ei, campo_ea], spacing=12),

        ft.Row([
            ft.ElevatedButton(
                "✅ Validar AFD",
                on_click=on_validar,
                style=ft.ButtonStyle(bgcolor="#37474F", color="white"),
            ),
            ft.ElevatedButton(
                "🔁 Convertir a ER  (paso a paso)",
                on_click=on_convertir,
                style=ft.ButtonStyle(bgcolor="#283593", color="white"),
            ),
        ], spacing=12),

        validez_label,

        ft.Divider(height=10),

        # Resultado inline
        er_resultado_card,

    ], spacing=12)
