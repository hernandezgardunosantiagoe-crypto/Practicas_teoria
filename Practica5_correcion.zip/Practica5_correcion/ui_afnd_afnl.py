"""
ui_afnd_afnl.py — Secciones de UI para AFND y AFN-λ (Flet 0.84.0)
"""
import flet as ft
from logic_afnd import simular_AFND, formatear_resultado_afnd
from logic_afnl import simular_AFNL, formatear_resultado_afnl, calcular_todas_clausuras
from ui_shared import abrir_ventana_resultado, mostrar_snack


# ═══════════════════════════════════════
#  SECCIÓN: AFND
# ═══════════════════════════════════════

def seccion_afnd(page: ft.Page) -> ft.Column:
    estados  = ["q0", "q1"]
    simbolos = ["a", "b"]
    tabla_container = ft.Column(scroll=ft.ScrollMode.AUTO)

    campo_ei     = ft.TextField(label="Estado inicial", value="q0", width=150)
    campo_ea     = ft.TextField(label="Estados de aceptación (comas)",
                                hint_text="Ej: q1,q2", width=300)
    campo_cadena = ft.TextField(label="Cadena a evaluar", hint_text="Ej: ab", width=300)
    celdas: dict = {}

    def reconstruir_tabla():
        celdas.clear()
        tabla_container.controls.clear()
        encabezado = ft.Row([
            ft.Container(ft.Text("δ", weight=ft.FontWeight.BOLD),
                         width=90, bgcolor="#E8F5E9", padding=5),
        ] + [
            ft.Container(ft.Text(s, weight=ft.FontWeight.BOLD),
                         width=130, bgcolor="#E8F5E9", padding=5)
            for s in simbolos
        ])
        tabla_container.controls.append(encabezado)
        for i, estado in enumerate(estados):
            fila = []
            for j in range(len(simbolos)):
                tf = ft.TextField(hint_text="q0,q1", width=120, height=45,
                                  text_size=12)
                celdas[(i, j)] = tf
                fila.append(tf)
            tabla_container.controls.append(ft.Row([
                ft.Container(ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
            ] + fila))
        page.update()

    def agregar_estado(e): estados.append(f"q{len(estados)}"); reconstruir_tabla()
    def quitar_estado(e):
        if len(estados) > 1: estados.pop(); reconstruir_tabla()
    def agregar_simbolo(e):
        letras = "abcdefghijklmnopqrstuvwxyz"
        nuevo = letras[len(simbolos)] if len(simbolos) < len(letras) else str(len(simbolos))
        simbolos.append(nuevo); reconstruir_tabla()
    def quitar_simbolo(e):
        if len(simbolos) > 1: simbolos.pop(); reconstruir_tabla()

    def on_simular(e):
        ei = campo_ei.value.strip()
        ea_str = campo_ea.value.strip()
        if not ei or not ea_str:
            mostrar_snack(page, "Completa el estado inicial y de aceptación.")
            return
        ea = {s.strip() for s in ea_str.split(",") if s.strip()}
        cadena = campo_cadena.value
        trans: dict = {}
        for i, estado in enumerate(estados):
            trans[estado] = {}
            for j, sim in enumerate(simbolos):
                val = celdas.get((i, j))
                val_str = val.value.strip() if val and val.value else ""
                if val_str:
                    trans[estado][sim] = {v.strip() for v in val_str.split(",") if v.strip()}
        resultado = simular_AFND(trans, ei, ea, cadena)
        texto = formatear_resultado_afnd(resultado, cadena, ei, ea)
        abrir_ventana_resultado(page, "Simulación AFND", texto,
                                resultado["aceptada"], "resultado_afnd.txt")

    reconstruir_tabla()

    return ft.Column([
        ft.Text("4. Simulador AFND (No Determinista)", size=20,
                weight=ft.FontWeight.BOLD, color="#2E7D32"),
        ft.Text("Cada celda acepta múltiples destinos separados por coma:",
                size=13, color="#555555"),
        ft.Row([
            ft.ElevatedButton("+ Estado",  on_click=agregar_estado),
            ft.ElevatedButton("- Estado",  on_click=quitar_estado),
            ft.ElevatedButton("+ Símbolo", on_click=agregar_simbolo),
            ft.ElevatedButton("- Símbolo", on_click=quitar_simbolo),
        ], spacing=8),
        ft.Container(content=tabla_container,
                     border=ft.border.all(1, "#A5D6A7"), border_radius=8, padding=10),
        ft.Row([campo_ei, campo_ea], spacing=12),
        campo_cadena,
        ft.ElevatedButton("Simular AFND", on_click=on_simular),
    ], spacing=12)


# ═══════════════════════════════════════
#  SECCIÓN: AFN-λ
# ═══════════════════════════════════════

def seccion_afnl(page: ft.Page) -> ft.Column:
    estados  = ["q0", "q1", "q2"]
    simbolos = ["a", "b"]
    tabla_container  = ft.Column(scroll=ft.ScrollMode.AUTO)
    lambda_container = ft.Column(scroll=ft.ScrollMode.AUTO)

    campo_ei     = ft.TextField(label="Estado inicial", value="q0", width=150)
    campo_ea     = ft.TextField(label="Estados de aceptación", hint_text="Ej: q2", width=250)
    campo_cadena = ft.TextField(label="Cadena a evaluar", hint_text="Ej: ab", width=250)
    celdas_sym: dict = {}
    celdas_lam: dict = {}

    def reconstruir_tablas():
        celdas_sym.clear(); celdas_lam.clear()
        tabla_container.controls.clear(); lambda_container.controls.clear()

        enc = ft.Row([
            ft.Container(ft.Text("δ", weight=ft.FontWeight.BOLD),
                         width=90, bgcolor="#EDE7F6", padding=5),
        ] + [
            ft.Container(ft.Text(s, weight=ft.FontWeight.BOLD),
                         width=130, bgcolor="#EDE7F6", padding=5)
            for s in simbolos
        ])
        tabla_container.controls.append(enc)
        for i, estado in enumerate(estados):
            fila = []
            for j in range(len(simbolos)):
                tf = ft.TextField(hint_text="q0,q1", width=120, height=45, text_size=12)
                celdas_sym[(i, j)] = tf
                fila.append(tf)
            tabla_container.controls.append(ft.Row([
                ft.Container(ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
            ] + fila))

        enc_l = ft.Row([
            ft.Container(ft.Text("λ-trans", weight=ft.FontWeight.BOLD),
                         width=90, bgcolor="#FCE4EC", padding=5),
            ft.Container(ft.Text("Destinos (λ)", weight=ft.FontWeight.BOLD),
                         width=200, bgcolor="#FCE4EC", padding=5),
        ])
        lambda_container.controls.append(enc_l)
        for i, estado in enumerate(estados):
            tf = ft.TextField(hint_text="q1,q2", width=190, height=45, text_size=12)
            celdas_lam[i] = tf
            lambda_container.controls.append(ft.Row([
                ft.Container(ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
                tf,
            ]))
        page.update()

    def agregar_estado(e): estados.append(f"q{len(estados)}"); reconstruir_tablas()
    def quitar_estado(e):
        if len(estados) > 1: estados.pop(); reconstruir_tablas()
    def agregar_simbolo(e):
        letras = "abcdefghijklmnopqrstuvwxyz"
        nuevo = letras[len(simbolos)] if len(simbolos) < len(letras) else str(len(simbolos))
        simbolos.append(nuevo); reconstruir_tablas()
    def quitar_simbolo(e):
        if len(simbolos) > 1: simbolos.pop(); reconstruir_tablas()

    def _parse_tablas():
        trans = {}
        trans_lam = {}
        for i, estado in enumerate(estados):
            trans[estado] = {}
            for j, sym in enumerate(simbolos):
                tf = celdas_sym.get((i, j))
                val = tf.value.strip() if tf and tf.value else ""
                if val:
                    trans[estado][sym] = {v.strip() for v in val.split(",") if v.strip()}
            tf_l = celdas_lam.get(i)
            val_l = tf_l.value.strip() if tf_l and tf_l.value else ""
            if val_l:
                trans_lam[estado] = {v.strip() for v in val_l.split(",") if v.strip()}
        return trans, trans_lam

    def on_simular(e):
        ei = campo_ei.value.strip()
        ea_str = campo_ea.value.strip()
        if not ei or not ea_str:
            mostrar_snack(page, "Completa el estado inicial y de aceptación.")
            return
        ea = {s.strip() for s in ea_str.split(",") if s.strip()}
        cadena = campo_cadena.value
        trans, trans_lam = _parse_tablas()
        resultado = simular_AFNL(trans, trans_lam, ei, ea, cadena)
        texto = formatear_resultado_afnl(resultado, cadena, ei, ea)
        abrir_ventana_resultado(page, "Simulación AFN-λ", texto,
                                resultado["aceptada"], "resultado_afnl.txt")

    def on_ver_clausuras(e):
        trans, trans_lam = _parse_tablas()
        clausuras = calcular_todas_clausuras(estados, trans_lam)
        lineas = ["λ-CLAUSURAS:\n"]
        for est, cl in clausuras.items():
            lineas.append(f"  λ-clausura({est}) = {{{', '.join(sorted(cl))}}}")
        texto = "\n".join(lineas)
        abrir_ventana_resultado(page, "λ-clausuras", texto, None, "clausuras.txt")

    reconstruir_tablas()

    return ft.Column([
        ft.Text("5. Simulador AFN-λ (con Transiciones Lambda)", size=20,
                weight=ft.FontWeight.BOLD, color="#6A1B9A"),
        ft.Row([
            ft.ElevatedButton("+ Estado",  on_click=agregar_estado),
            ft.ElevatedButton("- Estado",  on_click=quitar_estado),
            ft.ElevatedButton("+ Símbolo", on_click=agregar_simbolo),
            ft.ElevatedButton("- Símbolo", on_click=quitar_simbolo),
        ], spacing=8),
        ft.Row([
            ft.Column([
                ft.Text("Transiciones con símbolo:", weight=ft.FontWeight.W_600),
                ft.Container(content=tabla_container,
                             border=ft.border.all(1, "#CE93D8"),
                             border_radius=8, padding=10),
            ]),
            ft.Column([
                ft.Text("Transiciones λ (epsilon):", weight=ft.FontWeight.W_600,
                        color="#C62828"),
                ft.Container(content=lambda_container,
                             border=ft.border.all(1, "#EF9A9A"),
                             border_radius=8, padding=10),
            ]),
        ], spacing=20, wrap=True),
        ft.Row([campo_ei, campo_ea], spacing=12),
        campo_cadena,
        ft.Row([
            ft.ElevatedButton("Simular AFN-λ", on_click=on_simular),
            ft.ElevatedButton("Ver λ-clausuras", on_click=on_ver_clausuras),
        ], spacing=12),
    ], spacing=12)
