"""
ui_conversion.py — Conversiones entre autómatas (Flet 0.84.0)
"""
import flet as ft
from logic_conversion import (
    afnd_a_afd, formatear_conversion_afnd_afd,
    afnl_a_afnd, formatear_eliminacion_lambda,
)
from ui_shared import abrir_ventana_resultado, mostrar_snack


def seccion_conversion_afnd_afd(page: ft.Page) -> ft.Column:
    estados  = ["q0", "q1", "q2"]
    simbolos = ["a", "b"]
    tabla_container = ft.Column(scroll=ft.ScrollMode.AUTO)
    campo_ei = ft.TextField(label="Estado inicial", value="q0", width=150)
    campo_ea = ft.TextField(label="Estados de aceptación", hint_text="Ej: q2", width=250)
    celdas: dict = {}

    def reconstruir_tabla():
        celdas.clear(); tabla_container.controls.clear()
        enc = ft.Row([
            ft.Container(ft.Text("δ", weight=ft.FontWeight.BOLD),
                         width=90, bgcolor="#E3F2FD", padding=5),
        ] + [
            ft.Container(ft.Text(s, weight=ft.FontWeight.BOLD),
                         width=130, bgcolor="#E3F2FD", padding=5)
            for s in simbolos
        ])
        tabla_container.controls.append(enc)
        for i, estado in enumerate(estados):
            fila = []
            for j in range(len(simbolos)):
                tf = ft.TextField(hint_text="q0,q1", width=120, height=45, text_size=12)
                celdas[(i, j)] = tf
                fila.append(tf)
            tabla_container.controls.append(ft.Row([
                ft.Container(ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
            ] + fila))
        page.update()

    def agregar_estado(e): estados.append(f"q{len(estados)}"); reconstruir_tabla()
    def quitar_estado(e):
        if len(estados) > 1: estados.pop(); reconstruir_tabla()
    def agregar_simbolo(e):
        letras = "abcdefghijklmnopqrstuvwxyz"
        nuevo = letras[len(simbolos)] if len(simbolos) < len(letras) else str(len(simbolos))
        simbolos.append(nuevo); reconstruir_tabla()
    def quitar_simbolo(e):
        if len(simbolos) > 1: simbolos.pop(); reconstruir_tabla()

    def on_convertir(e):
        ei = campo_ei.value.strip()
        ea_str = campo_ea.value.strip()
        if not ei or not ea_str:
            mostrar_snack(page, "Completa estado inicial y de aceptación.")
            return
        ea = {s.strip() for s in ea_str.split(",") if s.strip()}
        trans_nd: dict = {}
        for i, estado in enumerate(estados):
            trans_nd[estado] = {}
            for j, sym in enumerate(simbolos):
                tf = celdas.get((i, j))
                val = tf.value.strip() if tf and tf.value else ""
                if val:
                    trans_nd[estado][sym] = {v.strip() for v in val.split(",") if v.strip()}
        resultado = afnd_a_afd(trans_nd, ei, ea, simbolos)
        texto = formatear_conversion_afnd_afd(resultado)
        abrir_ventana_resultado(page, "AFND → AFD", texto, None, "conversion_afnd_afd.txt")

    reconstruir_tabla()

    return ft.Column([
        ft.Text("6. Conversión AFND → AFD (Subconjuntos)", size=20,
                weight=ft.FontWeight.BOLD, color="#0277BD"),
        ft.Row([
            ft.ElevatedButton("+ Estado",  on_click=agregar_estado),
            ft.ElevatedButton("- Estado",  on_click=quitar_estado),
            ft.ElevatedButton("+ Símbolo", on_click=agregar_simbolo),
            ft.ElevatedButton("- Símbolo", on_click=quitar_simbolo),
        ], spacing=8),
        ft.Container(content=tabla_container,
                     border=ft.border.all(1, "#90CAF9"), border_radius=8, padding=10),
        ft.Row([campo_ei, campo_ea], spacing=12),
        ft.ElevatedButton("Convertir a AFD", on_click=on_convertir),
    ], spacing=12)


def seccion_eliminacion_lambda(page: ft.Page) -> ft.Column:
    estados  = ["q0", "q1", "q2"]
    simbolos = ["a", "b"]
    tabla_container  = ft.Column(scroll=ft.ScrollMode.AUTO)
    lambda_container = ft.Column(scroll=ft.ScrollMode.AUTO)
    campo_ei = ft.TextField(label="Estado inicial", value="q0", width=150)
    campo_ea = ft.TextField(label="Estados de aceptación", hint_text="Ej: q2", width=250)
    celdas_sym: dict = {}
    celdas_lam: dict = {}

    def reconstruir_tablas():
        celdas_sym.clear(); celdas_lam.clear()
        tabla_container.controls.clear(); lambda_container.controls.clear()

        enc = ft.Row([
            ft.Container(ft.Text("δ", weight=ft.FontWeight.BOLD),
                         width=90, bgcolor="#FFF8E1", padding=5),
        ] + [
            ft.Container(ft.Text(s, weight=ft.FontWeight.BOLD),
                         width=130, bgcolor="#FFF8E1", padding=5)
            for s in simbolos
        ])
        tabla_container.controls.append(enc)
        for i, estado in enumerate(estados):
            fila = []
            for j in range(len(simbolos)):
                tf = ft.TextField(hint_text="q0,q1", width=120, height=45, text_size=12)
                celdas_sym[(i, j)] = tf
                fila.append(tf)
            tabla_container.controls.append(ft.Row([
                ft.Container(ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
            ] + fila))

        enc_l = ft.Row([
            ft.Container(ft.Text("Estado", weight=ft.FontWeight.BOLD),
                         width=90, bgcolor="#FFCCBC", padding=5),
            ft.Container(ft.Text("λ-destinos", weight=ft.FontWeight.BOLD),
                         width=200, bgcolor="#FFCCBC", padding=5),
        ])
        lambda_container.controls.append(enc_l)
        for i, estado in enumerate(estados):
            tf = ft.TextField(hint_text="q1,q2", width=190, height=45, text_size=12)
            celdas_lam[i] = tf
            lambda_container.controls.append(ft.Row([
                ft.Container(ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
                tf,
            ]))
        page.update()

    def agregar_estado(e): estados.append(f"q{len(estados)}"); reconstruir_tablas()
    def quitar_estado(e):
        if len(estados) > 1: estados.pop(); reconstruir_tablas()
    def agregar_simbolo(e):
        letras = "abcdefghijklmnopqrstuvwxyz"
        nuevo = letras[len(simbolos)] if len(simbolos) < len(letras) else str(len(simbolos))
        simbolos.append(nuevo); reconstruir_tablas()
    def quitar_simbolo(e):
        if len(simbolos) > 1: simbolos.pop(); reconstruir_tablas()

    def on_eliminar(e):
        ei = campo_ei.value.strip()
        ea_str = campo_ea.value.strip()
        if not ei or not ea_str:
            mostrar_snack(page, "Completa estado inicial y de aceptación.")
            return
        ea = {s.strip() for s in ea_str.split(",") if s.strip()}
        trans: dict = {}
        trans_lam: dict = {}
        for i, estado in enumerate(estados):
            trans[estado] = {}
            for j, sym in enumerate(simbolos):
                tf = celdas_sym.get((i, j))
                val = tf.value.strip() if tf and tf.value else ""
                if val:
                    trans[estado][sym] = {v.strip() for v in val.split(",") if v.strip()}
            tf_l = celdas_lam.get(i)
            val_l = tf_l.value.strip() if tf_l and tf_l.value else ""
            if val_l:
                trans_lam[estado] = {v.strip() for v in val_l.split(",") if v.strip()}
        resultado = afnl_a_afnd(trans, trans_lam, ei, ea, estados, simbolos)
        texto = formatear_eliminacion_lambda(resultado)
        abrir_ventana_resultado(page, "AFN-λ → AFND", texto, None, "eliminacion_lambda.txt")

    reconstruir_tablas()

    return ft.Column([
        ft.Text("7. Eliminación de λ-transiciones (AFN-λ → AFND)", size=20,
                weight=ft.FontWeight.BOLD, color="#E65100"),
        ft.Row([
            ft.ElevatedButton("+ Estado",  on_click=agregar_estado),
            ft.ElevatedButton("- Estado",  on_click=quitar_estado),
            ft.ElevatedButton("+ Símbolo", on_click=agregar_simbolo),
            ft.ElevatedButton("- Símbolo", on_click=quitar_simbolo),
        ], spacing=8),
        ft.Row([
            ft.Column([
                ft.Text("Transiciones normales:", weight=ft.FontWeight.W_600),
                ft.Container(content=tabla_container,
                             border=ft.border.all(1, "#FFCC02"),
                             border_radius=8, padding=10),
            ]),
            ft.Column([
                ft.Text("Transiciones λ:", weight=ft.FontWeight.W_600,
                        color="#BF360C"),
                ft.Container(content=lambda_container,
                             border=ft.border.all(1, "#FF8A65"),
                             border_radius=8, padding=10),
            ]),
        ], spacing=20, wrap=True),
        ft.Row([campo_ei, campo_ea], spacing=12),
        ft.ElevatedButton("Eliminar λ-transiciones", on_click=on_eliminar),
    ], spacing=12)
