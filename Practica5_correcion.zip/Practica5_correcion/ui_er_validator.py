"""
ui_er_validator.py — UI para Validadores con Expresiones Regulares (Ejercicio 3)
Compatible con Flet 0.84.0
"""
import flet as ft
from logic_er_validator import validar, formatear_validacion, obtener_afd_equivalente, PATRONES
from ui_shared import abrir_ventana_resultado, mostrar_snack


def seccion_er_validadores(page: ft.Page) -> ft.Column:
    """Sección principal: selector de validador + panel de validación."""

    # ── Selector de tipo de validador ───────────────────────────
    tipos = list(PATRONES.keys())
    nombres = [PATRONES[t]["nombre"] for t in tipos]
    tipo_seleccionado = {"v": tipos[0]}

    tabs_container = ft.Row(spacing=6, wrap=True)
    botones_tabs: list = []

    # Panel de información del patrón
    er_display = ft.Text("", size=12, selectable=True,
                         font_family="monospace", color="#37474F")
    formato_display = ft.Text("", size=13, italic=True, color="#555555")
    ejemplos_display = ft.Text("", size=12, color="#1B5E20")

    # Área de entrada y resultado
    campo_texto = ft.TextField(
        label="Texto a validar",
        hint_text="Escribe aquí...",
        width=480,
        on_submit=lambda e: on_validar(e),
    )

    resultado_icon   = ft.Text("", size=30)
    resultado_texto  = ft.Text("", size=16, weight=ft.FontWeight.BOLD)
    resultado_detail = ft.Text("", size=13, color="#555555")
    sugerencias_col  = ft.Column([], spacing=4, visible=False)

    resultado_card = ft.Container(
        content=ft.Column([
            ft.Row([resultado_icon, resultado_texto], spacing=10),
            resultado_detail,
            sugerencias_col,
        ]),
        padding=14,
        border_radius=10,
        border=ft.border.all(2, "#BDBDBD"),
        visible=False,
    )

    def _actualizar_info_patron():
        t = tipo_seleccionado["v"]
        info = PATRONES[t]
        er_display.value   = info["er"]
        formato_display.value = f"Formato: {info['descripcion']}"
        ejemplos_display.value = "Ejemplos válidos: " + " | ".join(info["ejemplos_validos"])
        campo_texto.label  = f"Texto a validar ({info['nombre']})"
        campo_texto.value  = ""
        resultado_card.visible = False
        page.update()

    def _seleccionar_tab(tipo: str):
        tipo_seleccionado["v"] = tipo
        for i, btn in enumerate(botones_tabs):
            btn.style = ft.ButtonStyle(
                bgcolor="#283593" if tipos[i] == tipo else "#ECEFF1",
                color="white" if tipos[i] == tipo else "#37474F",
            )
        _actualizar_info_patron()

    for t in tipos:
        info = PATRONES[t]
        btn = ft.ElevatedButton(
            info["nombre"],
            on_click=lambda e, _t=t: _seleccionar_tab(_t),
            style=ft.ButtonStyle(
                bgcolor="#283593" if t == tipos[0] else "#ECEFF1",
                color="white" if t == tipos[0] else "#37474F",
            ),
        )
        botones_tabs.append(btn)
        tabs_container.controls.append(btn)

    # ── Validación ───────────────────────────────────────────────

    def on_validar(e):
        texto = campo_texto.value or ""
        t = tipo_seleccionado["v"]

        if not texto:
            mostrar_snack(page, "Ingresa un texto para validar.")
            return

        res = validar(t, texto)

        # Actualizar card de resultado
        if res["valido"]:
            resultado_icon.value  = "✅"
            resultado_texto.value = "VÁLIDO"
            resultado_texto.color = "#1B5E20"
            resultado_detail.value = f"El texto cumple el patrón de {res['nombre']}."
            resultado_card.border = ft.border.all(2, "#66BB6A")
            resultado_card.bgcolor = "#F1F8E9"
            sugerencias_col.visible = False
            sugerencias_col.controls.clear()
        else:
            resultado_icon.value  = "❌"
            resultado_texto.value = "INVÁLIDO"
            resultado_texto.color = "#B71C1C"
            resultado_detail.value = f"El texto NO cumple el patrón de {res['nombre']}."
            resultado_card.border = ft.border.all(2, "#EF9A9A")
            resultado_card.bgcolor = "#FFF3F3"

            sugerencias_col.controls.clear()
            sugerencias_col.controls.append(
                ft.Text("Sugerencias de corrección:",
                        weight=ft.FontWeight.W_600, color="#B71C1C", size=13)
            )
            for s in res["sugerencias"]:
                sugerencias_col.controls.append(
                    ft.Row([
                        ft.Icon(ft.Icons.ARROW_RIGHT, size=14, color="#E57373"),
                        ft.Text(s, size=12, color="#555555"),
                    ])
                )
            sugerencias_col.visible = True

        resultado_card.visible = True
        page.update()

    # ── Ver proceso completo ─────────────────────────────────────

    def on_ver_detalle(e):
        texto = campo_texto.value or ""
        if not texto:
            mostrar_snack(page, "Primero ingresa un texto y valida.")
            return
        t = tipo_seleccionado["v"]
        res = validar(t, texto)
        texto_reporte = formatear_validacion(res, texto)
        abrir_ventana_resultado(
            page,
            f"Detalle — {res['nombre']}",
            texto_reporte,
            res["valido"],
            f"validacion_{t}.txt",
        )

    def on_ver_afd(e):
        t = tipo_seleccionado["v"]
        texto_afd = obtener_afd_equivalente(t)
        nombre = PATRONES[t]["nombre"]
        abrir_ventana_resultado(
            page,
            f"AFD equivalente — {nombre}",
            texto_afd,
            None,
            f"afd_equivalente_{t}.txt",
        )

    # ── Inicializar ──────────────────────────────────────────────
    _actualizar_info_patron()

    # ── Layout ──────────────────────────────────────────────────
    return ft.Column([
        ft.Text("11. Validadores con Expresiones Regulares",
                size=20, weight=ft.FontWeight.BOLD, color="#4A148C"),
        ft.Text(
            "Selecciona un tipo de validador, ingresa un texto y comprueba si cumple el patrón.",
            size=13, color="#555555",
        ),

        ft.Divider(height=8),

        # Tabs de tipo
        ft.Text("Tipo de validador:", weight=ft.FontWeight.W_600),
        tabs_container,

        ft.Divider(height=6),

        # Info del patrón
        ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Icon(ft.Icons.CODE, size=16, color="#7E57C2"),
                    ft.Text("Expresión Regular:", weight=ft.FontWeight.W_600,
                            size=13, color="#7E57C2"),
                ]),
                er_display,
                formato_display,
                ejemplos_display,
            ], spacing=4),
            bgcolor="#F3E5F5",
            border=ft.border.all(1, "#CE93D8"),
            border_radius=8,
            padding=12,
        ),

        ft.Divider(height=6),

        # Entrada de texto
        ft.Text("Texto a validar:", weight=ft.FontWeight.W_600),
        campo_texto,

        ft.Row([
            ft.ElevatedButton(
                "🔍 Validar",
                on_click=on_validar,
                style=ft.ButtonStyle(bgcolor="#4A148C", color="white"),
            ),
            ft.ElevatedButton(
                "📄 Ver detalle completo",
                on_click=on_ver_detalle,
            ),
            ft.ElevatedButton(
                "🔷 Ver AFD equivalente",
                on_click=on_ver_afd,
            ),
        ], spacing=10),

        # Resultado
        resultado_card,

    ], spacing=12)
