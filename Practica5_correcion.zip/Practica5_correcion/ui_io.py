"""
ui_io.py — I/O y Pruebas Múltiples (Flet 0.84.0)
FilePicker no es compatible en esta versión, se usa campo de texto para rutas.
"""
import flet as ft
from logic_io import (
    exportar_json, exportar_txt, exportar_jff,
    importar_json, importar_jff,
    formatear_pruebas_multiples,
)
from logic_afd  import simular_AFD
from logic_afnd import simular_AFND
from ui_shared  import abrir_ventana_resultado, mostrar_snack, guardar_archivo


def seccion_io_pruebas(page: ft.Page) -> ft.Column:
    automata_cargado = {"data": None}
    info_label = ft.Text("Sin autómata cargado.", italic=True, color="#888888")

    # Ruta manual en lugar de FilePicker
    campo_ruta = ft.TextField(
        label="Ruta del archivo a importar (.json o .jff)",
        hint_text=r"Ej: C:\proyecto\automata.json",
        width=500,
    )

    campo_cadenas = ft.TextField(
        label="Cadenas a probar (separadas por coma)",
        hint_text="Ej: ab,ba,aab",
        multiline=True,
        min_lines=4,
        max_lines=8,
        width=450,
    )
    resultado_text = ft.TextField(
        value="",
        multiline=True,
        read_only=True,
        min_lines=6,
        max_lines=15,
        width=600,
        visible=False,
    )

    def _actualizar_info(data):
        automata_cargado["data"] = data
        info_label.value = (
            f"✅ Cargado: {data.get('tipo','?')} | "
            f"Estados: {len(data.get('estados',[]))} | "
            f"Alfabeto: {', '.join(data.get('simbolos',[]))}"
        )
        page.update()

    def on_importar(e):
        ruta = campo_ruta.value.strip()
        if not ruta:
            mostrar_snack(page, "Ingresa la ruta del archivo.")
            return
        try:
            if ruta.lower().endswith(".json"):
                data = importar_json(ruta)
            elif ruta.lower().endswith(".jff") or ruta.lower().endswith(".xml"):
                data = importar_jff(ruta)
            else:
                mostrar_snack(page, "Formato no reconocido. Usa .json o .jff")
                return
            _actualizar_info(data)
        except FileNotFoundError:
            info_label.value = f"❌ Archivo no encontrado: {ruta}"
            page.update()
        except Exception as ex:
            info_label.value = f"❌ Error al importar: {ex}"
            page.update()

    def on_exportar(formato: str):
        data = automata_cargado.get("data")
        if not data:
            mostrar_snack(page, "Primero carga un autómata.")
            return
        try:
            if formato == "json":
                ruta = exportar_json(data, "automata_exportado.json")
            elif formato == "txt":
                ruta = exportar_txt(data, "automata_exportado.txt")
            else:
                ruta = exportar_jff(data, "automata_exportado.jff")
            mostrar_snack(page, f"✅ Exportado en: {ruta}")
        except Exception as ex:
            mostrar_snack(page, f"❌ Error al exportar: {ex}")

    def on_probar(e):
        data = automata_cargado.get("data")
        if not data:
            mostrar_snack(page, "Primero importa un autómata.")
            return
        raw = campo_cadenas.value.strip()
        if not raw:
            mostrar_snack(page, "Ingresa al menos una cadena.")
            return

        cadenas = []
        for c in raw.split(","):
            c = c.strip()
            if c == "ε" or c == "":
                cadenas.append("")
            elif c:
                cadenas.append(c)

        tipo  = data.get("tipo", "AFD")
        trans = data.get("transiciones", {})
        ei    = data.get("estado_inicial", "")
        ea    = data.get("estados_aceptacion", set())
        if not isinstance(ea, set):
            ea = set(ea)

        resultados = []
        for cadena in cadenas:
            if tipo == "AFD":
                r = simular_AFD(trans, ei, ea, cadena)
            else:
                r = simular_AFND(trans, ei, ea, cadena)
            resultados.append({"cadena": cadena, "aceptada": r["aceptada"]})

        texto = formatear_pruebas_multiples(resultados, tipo)
        resultado_text.value = texto
        resultado_text.visible = True
        page.update()

    def on_guardar_informe(e):
        if not resultado_text.value:
            mostrar_snack(page, "Primero ejecuta las pruebas.")
            return
        ruta = guardar_archivo("informe_pruebas.txt", resultado_text.value)
        mostrar_snack(page, f"✅ Informe guardado en: {ruta}")

    return ft.Column([
        ft.Text("9. Importación / Exportación y Pruebas Múltiples",
                size=20, weight=ft.FontWeight.BOLD, color="#004D40"),

        # ── Importar ──
        ft.Text("Importar autómata desde archivo:", weight=ft.FontWeight.W_600),
        campo_ruta,
        ft.ElevatedButton("Importar", on_click=on_importar),
        info_label,

        ft.Divider(),

        # ── Exportar ──
        ft.Text("Exportar autómata cargado:", weight=ft.FontWeight.W_600),
        ft.Row([
            ft.ElevatedButton("Exportar JSON", on_click=lambda _: on_exportar("json")),
            ft.ElevatedButton("Exportar TXT",  on_click=lambda _: on_exportar("txt")),
            ft.ElevatedButton("Exportar JFF",  on_click=lambda _: on_exportar("jff")),
        ], spacing=10),

        ft.Divider(),

        # ── Pruebas Múltiples ──
        ft.Text("Pruebas Múltiples:", weight=ft.FontWeight.W_600),
        campo_cadenas,
        ft.Row([
            ft.ElevatedButton("Ejecutar pruebas", on_click=on_probar),
            ft.ElevatedButton("Guardar informe",  on_click=on_guardar_informe),
        ], spacing=10),
        resultado_text,
    ], spacing=12)