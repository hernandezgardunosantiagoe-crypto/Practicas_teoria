"""
ui_minimizacion.py — Minimización de AFD (Flet 0.84.0)
"""
import flet as ft
from logic_minimizacion import minimizar_afd, formatear_minimizacion
from logic_afd import simular_AFD
from ui_shared import abrir_ventana_resultado, mostrar_snack


def seccion_minimizacion(page: ft.Page) -> ft.Column:
    estados  = ["q0", "q1", "q2", "q3"]
    simbolos = ["a", "b"]
    tabla_container = ft.Column(scroll=ft.ScrollMode.AUTO)
    campo_ei = ft.TextField(label="Estado inicial", value="q0", width=150)
    campo_ea = ft.TextField(label="Estados de aceptación", hint_text="Ej: q1,q3", width=270)
    campo_cadenas_test = ft.TextField(
        label="Cadenas de prueba (separadas por coma)",
        hint_text="Ej: ab,ba,aab,bba",
        width=450,
    )
    celdas: dict = {}

    def reconstruir_tabla():
        celdas.clear(); tabla_container.controls.clear()
        enc = ft.Row([
            ft.Container(ft.Text("δ", weight=ft.FontWeight.BOLD),
                         width=90, bgcolor="#F3E5F5", padding=5),
        ] + [
            ft.Container(ft.Text(s, weight=ft.FontWeight.BOLD),
                         width=110, bgcolor="#F3E5F5", padding=5)
            for s in simbolos
        ])
        tabla_container.controls.append(enc)
        for i, estado in enumerate(estados):
            fila = []
            for j in range(len(simbolos)):
                tf = ft.TextField(hint_text="q?", width=100, height=45, text_size=12)
                celdas[(i, j)] = tf
                fila.append(tf)
            tabla_container.controls.append(ft.Row([
                ft.Container(ft.Text(estado, weight=ft.FontWeight.BOLD),
                             width=90, padding=5),
            ] + fila))
        page.update()

    def agregar_estado(e): estados.append(f"q{len(estados)}"); reconstruir_tabla()
    def quitar_estado(e):
        if len(estados) > 1: estados.pop(); reconstruir_tabla()
    def agregar_simbolo(e):
        letras = "abcdefghijklmnopqrstuvwxyz"
        nuevo = letras[len(simbolos)] if len(simbolos) < len(letras) else str(len(simbolos))
        simbolos.append(nuevo); reconstruir_tabla()
    def quitar_simbolo(e):
        if len(simbolos) > 1: simbolos.pop(); reconstruir_tabla()

    def _parse_trans():
        trans = {}
        for i, estado in enumerate(estados):
            trans[estado] = {}
            for j, sym in enumerate(simbolos):
                tf = celdas.get((i, j))
                val = tf.value.strip() if tf and tf.value else ""
                if val:
                    trans[estado][sym] = val
        return trans

    def on_minimizar(e):
        ei = campo_ei.value.strip()
        ea_str = campo_ea.value.strip()
        if not ei or not ea_str:
            mostrar_snack(page, "Completa estado inicial y de aceptación.")
            return
        ea = {s.strip() for s in ea_str.split(",") if s.strip()}
        trans = _parse_trans()
        resultado = minimizar_afd(trans, ei, ea, simbolos)
        texto = formatear_minimizacion(resultado)

        cadenas_str = campo_cadenas_test.value.strip()
        if cadenas_str:
            cadenas = [c.strip() if c.strip() != "ε" else ""
                       for c in cadenas_str.split(",") if c.strip()]
            texto += "\n─── PRUEBAS DE EQUIVALENCIA ───\n"
            texto += f"{'Cadena':<20} {'AFD Original':<18} {'AFD Mínimo'}\n"
            texto += "-" * 55 + "\n"
            afd_min = resultado["afd_minimo"]
            for cadena in cadenas:
                r_orig = simular_AFD(trans, ei, ea, cadena)
                r_min  = simular_AFD(afd_min["transiciones"],
                                     afd_min["estado_inicial"],
                                     afd_min["estados_aceptacion"], cadena)
                cad_str = f"'{cadena}'" if cadena else "'ε'"
                orig_r = "✅" if r_orig["aceptada"] else "❌"
                min_r  = "✅" if r_min["aceptada"]  else "❌"
                eq     = "≡" if r_orig["aceptada"] == r_min["aceptada"] else "≠ ERROR"
                texto += f"{cad_str:<20} {orig_r:<18} {min_r}  {eq}\n"

        abrir_ventana_resultado(page, "Minimización de AFD", texto, None, "minimizacion_afd.txt")

    reconstruir_tabla()

    return ft.Column([
        ft.Text("8. Minimización de AFD (Hopcroft)", size=20,
                weight=ft.FontWeight.BOLD, color="#4A148C"),
        ft.Row([
            ft.ElevatedButton("+ Estado",  on_click=agregar_estado),
            ft.ElevatedButton("- Estado",  on_click=quitar_estado),
            ft.ElevatedButton("+ Símbolo", on_click=agregar_simbolo),
            ft.ElevatedButton("- Símbolo", on_click=quitar_simbolo),
        ], spacing=8),
        ft.Container(content=tabla_container,
                     border=ft.border.all(1, "#CE93D8"), border_radius=8, padding=10),
        ft.Row([campo_ei, campo_ea], spacing=12),
        campo_cadenas_test,
        ft.ElevatedButton("Minimizar AFD", on_click=on_minimizar),
    ], spacing=12)
