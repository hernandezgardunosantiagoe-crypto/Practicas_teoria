"""
ui_shared.py — Utilidades compartidas de UI (compatible con Flet 0.84.0)
"""
import os
import flet as ft


def guardar_archivo(nombre: str, contenido: str) -> str:
    ruta = os.path.abspath(nombre)
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(contenido)
    return ruta


def mostrar_snack(page: ft.Page, msg: str):
    page.show_dialog(ft.SnackBar(content=ft.Text(msg), open=True))


def abrir_ventana_resultado(page: ft.Page, titulo: str, texto: str,
                             aceptada, nombre_archivo: str):
    if aceptada is None:
        color_titulo = "#333333"
        titulo_completo = titulo
    elif aceptada:
        color_titulo = "green"
        titulo_completo = f"✅ ACEPTADA — {titulo}"
    else:
        color_titulo = "red"
        titulo_completo = f"❌ RECHAZADA — {titulo}"

    def cerrar(e):
        page.pop_dialog()
        page.update()

    def guardar(e):
        try:
            ruta = guardar_archivo(nombre_archivo, texto)
            page.pop_dialog()
            page.update()
            page.show_dialog(ft.SnackBar(
                content=ft.Text(f"✅ Guardado en: {ruta}"), open=True))
        except Exception as ex:
            page.show_dialog(ft.SnackBar(
                content=ft.Text(f"❌ Error: {ex}"), open=True))

    dialogo = ft.AlertDialog(
        modal=True,
        title=ft.Text(titulo_completo, weight=ft.FontWeight.BOLD,
                      color=color_titulo, size=16),
        content=ft.Container(
            width=680,
            height=460,
            content=ft.TextField(
                value=texto,
                multiline=True,
                read_only=True,
                expand=True,
                min_lines=18,
                max_lines=35,
            ),
        ),
        actions=[
            ft.TextButton("💾 Guardar", on_click=guardar),
            ft.TextButton("Cerrar", on_click=cerrar),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )

    page.show_dialog(dialogo)
    page.update()
