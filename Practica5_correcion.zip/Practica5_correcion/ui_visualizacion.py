"""
ui_visualizacion.py — Visualización Gráfica de Autómatas (Ejercicio 2)
Compatible con Flet 0.84.0

Funcionalidades:
  - Dibuja el autómata como grafo con estados (círculos) y transiciones (flechas)
  - Resalta el estado actual durante la simulación paso a paso
  - Soporta AFD, AFND y AFN-λ
  - Permite cargar autómata manualmente o importar desde JSON/JFF
  - Simulación interactiva: el usuario avanza símbolo a símbolo y ve el estado activo
"""
import math
import flet as ft
from logic_afd  import simular_AFD
from logic_afnd import simular_AFND
from logic_afnl import simular_AFNL
from logic_io   import importar_json, importar_jff
from ui_shared  import mostrar_snack
from flet import canvas

# ══════════════════════════════════════════════════════════════════
#  CONSTANTES DE DISEÑO
# ══════════════════════════════════════════════════════════════════
RADIO_ESTADO   = 28
ANCHO_CANVAS   = 780
ALTO_CANVAS    = 420
COLOR_NORMAL   = "#1565C0"   # azul — estado normal
COLOR_ACTIVO   = "#F57F17"   # naranja — estado activo (simulación)
COLOR_ACEPT    = "#2E7D32"   # verde — estado de aceptación
COLOR_ACEPT_ACT= "#FF6F00"   # naranja oscuro — aceptación + activo
COLOR_BORDE    = "#FFFFFF"
COLOR_TRANS    = "#37474F"
COLOR_FONDO    = "#FAFAFA"
FONT_ESTADO    = 13
FONT_SIM       = 12


# ══════════════════════════════════════════════════════════════════
#  CÁLCULO DE POSICIONES (layout circular)
# ══════════════════════════════════════════════════════════════════

def _calcular_posiciones(estados: list) -> dict:
    """Distribuye los estados en círculo dentro del canvas."""
    n = len(estados)
    if n == 0:
        return {}
    cx, cy = ANCHO_CANVAS // 2, ALTO_CANVAS // 2
    radio_layout = min(cx, cy) - RADIO_ESTADO - 30

    posiciones = {}
    if n == 1:
        posiciones[estados[0]] = (cx, cy)
    else:
        for i, est in enumerate(estados):
            angulo = (2 * math.pi * i / n) - math.pi / 2
            x = int(cx + radio_layout * math.cos(angulo))
            y = int(cy + radio_layout * math.sin(angulo))
            posiciones[est] = (x, y)
    return posiciones


# ══════════════════════════════════════════════════════════════════
#  GENERADOR DE SVG
# ══════════════════════════════════════════════════════════════════

def _generar_svg(estados: list, transiciones: dict, estado_inicial: str,
                 estados_aceptacion: set, estados_activos: set,
                 tipo: str = "AFD") -> str:
    """Genera un SVG que representa el autómata como grafo."""
    pos = _calcular_posiciones(estados)
    if not pos:
        return f'<svg width="{ANCHO_CANVAS}" height="{ALTO_CANVAS}" xmlns="http://www.w3.org/2000/svg"><text x="20" y="40" fill="#888">Sin estados definidos.</text></svg>'

    svg_parts = [
        f'<svg width="{ANCHO_CANVAS}" height="{ALTO_CANVAS}" xmlns="http://www.w3.org/2000/svg">',
        f'<rect width="{ANCHO_CANVAS}" height="{ALTO_CANVAS}" fill="{COLOR_FONDO}" rx="10"/>',
        # Marcador de punta de flecha
        '<defs>',
        '<marker id="arrow" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">',
        f'<polygon points="0 0, 10 3.5, 0 7" fill="{COLOR_TRANS}"/>',
        '</marker>',
        '<marker id="arrow_act" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">',
        '<polygon points="0 0, 10 3.5, 0 7" fill="#F57F17"/>',
        '</marker>',
        '</defs>',
    ]

    # ── 1. Dibujar transiciones ──────────────────────────────────
    # Agrupar arcos entre el mismo par de estados
    arcos: dict = {}   # (src, dst) -> lista de simbolos
    for src, trans in transiciones.items():
        for sym, dest in trans.items():
            # Normalizar destino (puede ser set en AFND)
            destinos = dest if isinstance(dest, (set, frozenset, list)) else {dest}
            for d in destinos:
                if d and d != "∅":
                    key = (src, str(d))
                    arcos.setdefault(key, []).append(sym)

    # Detectar pares bidireccionales para curvar
    pares_bidi = set()
    for (s, d) in arcos:
        if (d, s) in arcos and s != d:
            pares_bidi.add((s, d))

    for (src, dst), syms in arcos.items():
        etiqueta = ", ".join(syms)
        es_activo = src in estados_activos and dst in estados_activos

        if src not in pos or dst not in pos:
            continue

        x1, y1 = pos[src]
        x2, y2 = pos[dst]
        color_arco = "#F57F17" if es_activo else COLOR_TRANS
        marker = "url(#arrow_act)" if es_activo else "url(#arrow)"
        stroke_w = "2.5" if es_activo else "1.8"

        if src == dst:
            # Auto-lazo
            svg_parts.append(_auto_loop(x1, y1, etiqueta, color_arco, marker, stroke_w))
        else:
            curvar = (src, dst) in pares_bidi or (dst, src) in pares_bidi
            svg_parts.append(_flecha(x1, y1, x2, y2, etiqueta, color_arco,
                                      marker, stroke_w, curvar))

    # ── 2. Flecha indicando estado inicial ───────────────────────
    if estado_inicial in pos:
        xi, yi = pos[estado_inicial]
        svg_parts.append(
            f'<line x1="{xi - RADIO_ESTADO - 35}" y1="{yi}" '
            f'x2="{xi - RADIO_ESTADO - 2}" y2="{yi}" '
            f'stroke="{COLOR_TRANS}" stroke-width="2" marker-end="url(#arrow)"/>'
            f'<text x="{xi - RADIO_ESTADO - 55}" y="{yi - 6}" '
            f'font-size="10" fill="{COLOR_TRANS}">inicio</text>'
        )

    # ── 3. Dibujar estados ───────────────────────────────────────
    for est in estados:
        if est not in pos:
            continue
        x, y = pos[est]
        activo   = est in estados_activos
        acept    = est in estados_aceptacion

        if activo and acept:
            fill = COLOR_ACEPT_ACT
        elif activo:
            fill = COLOR_ACTIVO
        elif acept:
            fill = COLOR_ACEPT
        else:
            fill = COLOR_NORMAL

        # Sombra suave
        svg_parts.append(
            f'<circle cx="{x+2}" cy="{y+2}" r="{RADIO_ESTADO}" fill="#00000022"/>'
        )
        # Círculo exterior (doble borde para estados de aceptación)
        if acept:
            svg_parts.append(
                f'<circle cx="{x}" cy="{y}" r="{RADIO_ESTADO + 6}" '
                f'fill="none" stroke="{fill}" stroke-width="2"/>'
            )
        # Círculo principal
        svg_parts.append(
            f'<circle cx="{x}" cy="{y}" r="{RADIO_ESTADO}" '
            f'fill="{fill}" stroke="{COLOR_BORDE}" stroke-width="2"/>'
        )
        # Nombre del estado
        svg_parts.append(
            f'<text x="{x}" y="{y + 5}" text-anchor="middle" '
            f'font-size="{FONT_ESTADO}" fill="white" font-weight="bold" '
            f'font-family="monospace">{est}</text>'
        )

    svg_parts.append('</svg>')
    return "\n".join(svg_parts)


def _flecha(x1, y1, x2, y2, etiqueta, color, marker, stroke_w, curvar):
    """Dibuja una flecha entre dos estados (recta o curvada)."""
    dx, dy = x2 - x1, y2 - y1
    dist = math.hypot(dx, dy) or 1
    ux, uy = dx / dist, dy / dist

    # Ajustar puntos de inicio/fin para que toquen el borde del círculo
    sx = x1 + ux * (RADIO_ESTADO + 2)
    sy = y1 + uy * (RADIO_ESTADO + 2)
    ex = x2 - ux * (RADIO_ESTADO + 12)
    ey = y2 - uy * (RADIO_ESTADO + 12)

    if curvar:
        # Punto de control perpendicular
        px = (sx + ex) / 2 - uy * 40
        py = (sy + ey) / 2 + ux * 40
        path = f'M {sx:.1f},{sy:.1f} Q {px:.1f},{py:.1f} {ex:.1f},{ey:.1f}'
        # Posición de la etiqueta: punto medio de la curva
        lx = (sx + 2 * px + ex) / 4
        ly = (sy + 2 * py + ey) / 4 - 8
    else:
        path = f'M {sx:.1f},{sy:.1f} L {ex:.1f},{ey:.1f}'
        lx = (sx + ex) / 2
        ly = (sy + ey) / 2 - 8

    partes = [
        f'<path d="{path}" stroke="{color}" stroke-width="{stroke_w}" '
        f'fill="none" marker-end="{marker}"/>',
        f'<rect x="{lx - len(etiqueta)*3.5:.1f}" y="{ly - 10:.1f}" '
        f'width="{len(etiqueta)*7 + 6:.1f}" height="14" fill="white" opacity="0.8" rx="3"/>',
        f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="middle" '
        f'font-size="{FONT_SIM}" fill="{color}" font-weight="bold" '
        f'font-family="monospace">{etiqueta}</text>',
    ]
    return "\n".join(partes)


def _auto_loop(x, y, etiqueta, color, marker, stroke_w):
    """Dibuja un auto-lazo sobre el estado."""
    rx, ry = x, y - RADIO_ESTADO - 5
    path = (f'M {x - 15},{ry + 5} '
            f'C {x - 40},{ry - 35} {x + 40},{ry - 35} {x + 15},{ry + 5}')
    lx, ly = x, ry - 30
    partes = [
        f'<path d="{path}" stroke="{color}" stroke-width="{stroke_w}" '
        f'fill="none" marker-end="{marker}"/>',
        f'<rect x="{lx - len(etiqueta)*3.5:.1f}" y="{ly - 10:.1f}" '
        f'width="{len(etiqueta)*7 + 6:.1f}" height="14" fill="white" opacity="0.8" rx="3"/>',
        f'<text x="{lx}" y="{ly}" text-anchor="middle" '
        f'font-size="{FONT_SIM}" fill="{color}" font-weight="bold" '
        f'font-family="monospace">{etiqueta}</text>',
    ]
    return "\n".join(partes)


# ══════════════════════════════════════════════════════════════════
#  SECCIÓN PRINCIPAL DE UI
# ══════════════════════════════════════════════════════════════════

def seccion_visualizacion(page: ft.Page) -> ft.Column:
    # ── Estado mutable ───────────────────────────────────────────
    automata = {
        "tipo": "AFD",
        "estados": ["q0", "q1", "q2"],
        "simbolos": ["a", "b"],
        "estado_inicial": "q0",
        "estados_aceptacion": {"q2"},
        "transiciones": {
            "q0": {"a": "q1", "b": "q0"},
            "q1": {"a": "q2", "b": "q0"},
            "q2": {"a": "q2", "b": "q2"},
        },
    }
    sim_estado = {
        "paso":    0,
        "camino":  [],     # lista de conjuntos de estados activos
        "cadena":  "",
        "activos": set(),
    }

    # ── Canvas Flet ──────────────────────────────────────────────
    cv = canvas.Canvas(
        width=ANCHO_CANVAS,
        height=ALTO_CANVAS,
    )
    canvas_container = ft.Container(
        content=cv,
        border=ft.border.all(2, "#9FA8DA"),
        border_radius=12,
        bgcolor=COLOR_FONDO,
        width=ANCHO_CANVAS,
        height=ALTO_CANVAS,
    )

    # ── Etiquetas de información ─────────────────────────────────
    info_label = ft.Text("", size=13, color="#37474F")
    paso_label = ft.Text("", size=14, weight=ft.FontWeight.BOLD, color="#1565C0")
    resultado_label = ft.Text("", size=15, weight=ft.FontWeight.BOLD)

    # ── Campo de cadena para simular ────────────────────────────
    campo_cadena_sim = ft.TextField(
        label="Cadena a simular",
        hint_text="Ej: ab",
        width=260,
    )

    # ── Importación ─────────────────────────────────────────────
    campo_ruta_vis = ft.TextField(
        label="Ruta de archivo .json o .jff",
        hint_text=r"Ej: automata.json",
        width=420,
    )

    # ── Tabla manual compacta ────────────────────────────────────
    tabla_vis = ft.Column(scroll=ft.ScrollMode.AUTO)
    celdas_vis: dict = {}
    campo_ei_vis = ft.TextField(label="Estado inicial", value="q0", width=130)
    campo_ea_vis = ft.TextField(label="Estados de aceptación", hint_text="q2", width=240)
    campo_tipo   = ft.Dropdown(
        label="Tipo",
        width=120,
        value="AFD",
        options=[
            ft.dropdown.Option("AFD"),
            ft.dropdown.Option("AFND"),
            ft.dropdown.Option("AFN-λ"),
        ],
    )

    # ── Dibujo en canvas ─────────────────────────────────────────
    def _redibujar(estados_activos: set = None, actualizar: bool = True):
        if estados_activos is None:
            estados_activos = set()
        shapes = _calcular_shapes(
            automata["estados"],
            automata["transiciones"],
            automata["estado_inicial"],
            automata["estados_aceptacion"],
            estados_activos,
        )
        cv.shapes = shapes
        # Solo llamar update() si el canvas ya está montado en la página
        if actualizar:
            try:
                cv.update()
                page.update()
            except Exception:
                pass

    # ── Tabla manual ─────────────────────────────────────────────
    def _rebuild_tabla():
        celdas_vis.clear()
        tabla_vis.controls.clear()
        estados  = automata["estados"]
        simbolos = automata["simbolos"]
        enc = ft.Row([
            ft.Container(ft.Text("δ", weight=ft.FontWeight.BOLD),
                         width=75, bgcolor="#E3F2FD", padding=4),
        ] + [
            ft.Container(ft.Text(s, weight=ft.FontWeight.BOLD),
                         width=100, bgcolor="#E3F2FD", padding=4)
            for s in simbolos
        ])
        tabla_vis.controls.append(enc)
        for i, est in enumerate(estados):
            fila = []
            for j in range(len(simbolos)):
                tf = ft.TextField(hint_text="q?", width=90, height=40, text_size=11)
                celdas_vis[(i, j)] = tf
                fila.append(tf)
            tabla_vis.controls.append(ft.Row([
                ft.Container(ft.Text(est, weight=ft.FontWeight.BOLD),
                             width=75, padding=4),
            ] + fila))
        page.update()

    def _parse_manual():
        estados  = automata["estados"]
        simbolos = automata["simbolos"]
        tipo     = campo_tipo.value or "AFD"
        trans: dict = {}
        for i, est in enumerate(estados):
            trans[est] = {}
            for j, sym in enumerate(simbolos):
                tf = celdas_vis.get((i, j))
                val = tf.value.strip() if tf and tf.value else ""
                if val:
                    if tipo == "AFD":
                        trans[est][sym] = val
                    else:
                        trans[est][sym] = {v.strip() for v in val.split(",") if v.strip()}
        automata["transiciones"] = trans
        automata["tipo"]          = tipo
        automata["estado_inicial"] = campo_ei_vis.value.strip() or "q0"
        ea_str = campo_ea_vis.value.strip()
        automata["estados_aceptacion"] = {s.strip() for s in ea_str.split(",") if s.strip()}

    # Botones +/- estado/símbolo
    def _agregar_estado(e):
        automata["estados"].append(f"q{len(automata['estados'])}")
        _rebuild_tabla(); _redibujar()
    def _quitar_estado(e):
        if len(automata["estados"]) > 1:
            automata["estados"].pop()
            _rebuild_tabla(); _redibujar()
    def _agregar_simbolo(e):
        letras = "abcdefghijklmnopqrstuvwxyz"
        n = len(automata["simbolos"])
        automata["simbolos"].append(letras[n] if n < len(letras) else str(n))
        _rebuild_tabla()
    def _quitar_simbolo(e):
        if len(automata["simbolos"]) > 1:
            automata["simbolos"].pop()
            _rebuild_tabla()

    def on_aplicar_manual(e):
        _parse_manual()
        sim_estado["camino"]  = []
        sim_estado["paso"]    = 0
        sim_estado["activos"] = {automata["estado_inicial"]}
        _actualizar_info_sim()
        _redibujar({automata["estado_inicial"]})

    # ── Importar ─────────────────────────────────────────────────
    def on_importar_vis(e):
        ruta = campo_ruta_vis.value.strip()
        if not ruta:
            mostrar_snack(page, "Ingresa la ruta del archivo.")
            return
        try:
            if ruta.lower().endswith(".json"):
                data = importar_json(ruta)
            elif ruta.lower().endswith((".jff", ".xml")):
                data = importar_jff(ruta)
            else:
                mostrar_snack(page, "Usa archivos .json o .jff")
                return
            automata.update({
                "tipo":               data.get("tipo", "AFD"),
                "estados":            list(data.get("estados", ["q0"])),
                "simbolos":           list(data.get("simbolos", ["a"])),
                "estado_inicial":     data.get("estado_inicial", "q0"),
                "estados_aceptacion": set(data.get("estados_aceptacion", set())),
                "transiciones":       data.get("transiciones", {}),
            })
            campo_ei_vis.value = automata["estado_inicial"]
            campo_ea_vis.value = ", ".join(sorted(automata["estados_aceptacion"]))
            campo_tipo.value   = automata["tipo"]
            _rebuild_tabla()
            # Rellenar celdas
            trans = automata["transiciones"]
            for i, est in enumerate(automata["estados"]):
                for j, sym in enumerate(automata["simbolos"]):
                    dest = trans.get(est, {}).get(sym, "")
                    if isinstance(dest, (set, frozenset, list)):
                        dest = ", ".join(sorted(dest))
                    tf = celdas_vis.get((i, j))
                    if tf:
                        tf.value = dest
            sim_estado["camino"]  = []
            sim_estado["paso"]    = 0
            sim_estado["activos"] = {automata["estado_inicial"]}
            _actualizar_info_sim()
            _redibujar({automata["estado_inicial"]})
            mostrar_snack(page, f"✅ Autómata importado: {len(automata['estados'])} estados.")
        except FileNotFoundError:
            mostrar_snack(page, f"❌ Archivo no encontrado: {ruta}")
        except Exception as ex:
            mostrar_snack(page, f"❌ Error al importar: {ex}")

    # ── Simulación ───────────────────────────────────────────────
    def _actualizar_info_sim():
        paso = sim_estado["paso"]
        cadena = sim_estado["cadena"]
        camino = sim_estado["camino"]
        activos = sim_estado["activos"]

        if not camino:
            paso_label.value = "Presiona ▶ Iniciar para comenzar la simulación."
            resultado_label.value = ""
            info_label.value = (
                f"Autómata: {automata['tipo']} | "
                f"Estados: {len(automata['estados'])} | "
                f"Alfabeto: {{{', '.join(automata['simbolos'])}}}"
            )
            return

        if paso == 0:
            paso_label.value = f"Estado inicial: {{{', '.join(sorted(activos))}}}"
        elif paso <= len(cadena):
            sym = cadena[paso - 1]
            paso_label.value = (
                f"Paso {paso}/{len(cadena)}: símbolo '{sym}' → "
                f"estado(s): {{{', '.join(sorted(activos))}}}"
            )

        if paso >= len(cadena) and camino:
            aceptada = bool(activos & automata["estados_aceptacion"])
            resultado_label.value = "✅ ACEPTADA" if aceptada else "❌ RECHAZADA"
            resultado_label.color = "#1B5E20" if aceptada else "#B71C1C"
        else:
            resultado_label.value = ""

        page.update()

    def on_iniciar_sim(e):
        cadena = campo_cadena_sim.value  # puede ser vacía (ε)
        _parse_manual()
        tipo  = automata["tipo"]
        trans = automata["transiciones"]
        ei    = automata["estado_inicial"]
        ea    = automata["estados_aceptacion"]
        trans_lam: dict = {}  # para AFN-λ no tenemos tabla lambda aquí

        # Calcular camino completo
        camino_activos = [{ei}]   # paso 0 = estado inicial

        if tipo == "AFD":
            estado = ei
            for sym in cadena:
                dest = trans.get(estado, {}).get(sym)
                estado = dest if dest else None
                camino_activos.append({estado} if estado else set())
        elif tipo in ("AFND", "AFN-λ"):
            estados_act = {ei}
            for sym in cadena:
                siguientes = set()
                for est in estados_act:
                    destinos = trans.get(est, {}).get(sym, set())
                    if isinstance(destinos, str):
                        destinos = {destinos}
                    siguientes |= set(destinos)
                estados_act = siguientes
                camino_activos.append(set(estados_act))

        sim_estado["cadena"]  = cadena
        sim_estado["camino"]  = camino_activos
        sim_estado["paso"]    = 0
        sim_estado["activos"] = {ei}
        _actualizar_info_sim()
        _redibujar({ei})

    def on_paso_siguiente(e):
        paso   = sim_estado["paso"]
        camino = sim_estado["camino"]
        if not camino:
            mostrar_snack(page, "Primero inicia la simulación.")
            return
        if paso + 1 >= len(camino):
            mostrar_snack(page, "Ya llegaste al final de la cadena.")
            return
        sim_estado["paso"] += 1
        activos = camino[sim_estado["paso"]]
        sim_estado["activos"] = activos
        _redibujar(activos)
        _actualizar_info_sim()

    def on_paso_anterior(e):
        paso   = sim_estado["paso"]
        camino = sim_estado["camino"]
        if not camino or paso == 0:
            mostrar_snack(page, "Ya estás en el inicio.")
            return
        sim_estado["paso"] -= 1
        activos = camino[sim_estado["paso"]]
        sim_estado["activos"] = activos
        _redibujar(activos)
        _actualizar_info_sim()

    def on_sim_completa(e):
        """Ejecuta toda la simulación de golpe y resalta estados finales."""
        camino = sim_estado["camino"]
        if not camino:
            mostrar_snack(page, "Primero inicia la simulación.")
            return
        sim_estado["paso"] = len(camino) - 1
        activos = camino[-1]
        sim_estado["activos"] = activos
        _redibujar(activos)
        _actualizar_info_sim()

    def on_reset(e):
        sim_estado["paso"]    = 0
        sim_estado["camino"]  = []
        sim_estado["activos"] = {automata["estado_inicial"]}
        _actualizar_info_sim()
        _redibujar({automata["estado_inicial"]})

    # ── Inicializar ──────────────────────────────────────────────
    _rebuild_tabla()
    # Pre-rellenar celdas con el autómata de ejemplo
    for i, est in enumerate(automata["estados"]):
        for j, sym in enumerate(automata["simbolos"]):
            dest = automata["transiciones"].get(est, {}).get(sym, "")
            tf = celdas_vis.get((i, j))
            if tf:
                tf.value = str(dest)

    sim_estado["activos"] = {automata["estado_inicial"]}
    # Calcular shapes iniciales y pasarlas al canvas al crearlo (sin update)
    _redibujar({automata["estado_inicial"]}, actualizar=False)
    _actualizar_info_sim()

    # ── Layout ───────────────────────────────────────────────────
    return ft.Column([
        ft.Text("12. Visualización Gráfica de Autómatas",
                size=20, weight=ft.FontWeight.BOLD, color="#1A237E"),
        ft.Text(
            "Visualiza el autómata como grafo y simula cadenas paso a paso. "
            "Los estados de aceptación tienen doble círculo (🟢), "
            "el estado activo se resalta en naranja.",
            size=13, color="#555555",
        ),

        ft.Divider(height=8),

        # ── Fila principal: canvas + controles ──────────────────
        ft.Row([
            # Canvas
            ft.Column([
                canvas_container,
                info_label,
                paso_label,
                resultado_label,
            ], spacing=6),

            # Panel lateral
            ft.Column([
                # Importar
                ft.Text("📂 Importar autómata:", weight=ft.FontWeight.W_600, size=13),
                campo_ruta_vis,
                ft.ElevatedButton("Importar archivo", on_click=on_importar_vis,
                                  style=ft.ButtonStyle(bgcolor="#37474F", color="white")),

                ft.Divider(height=6),

                # Tipo
                campo_tipo,
                ft.Row([campo_ei_vis, campo_ea_vis], spacing=8),

                # Botones +/-
                ft.Row([
                    ft.ElevatedButton("+ Estado",  on_click=_agregar_estado),
                    ft.ElevatedButton("- Estado",  on_click=_quitar_estado),
                ], spacing=6),
                ft.Row([
                    ft.ElevatedButton("+ Símbolo", on_click=_agregar_simbolo),
                    ft.ElevatedButton("- Símbolo", on_click=_quitar_simbolo),
                ], spacing=6),

                # Tabla
                ft.Container(
                    content=tabla_vis,
                    border=ft.border.all(1, "#90CAF9"),
                    border_radius=8,
                    padding=8,
                    width=420,
                ),

                ft.ElevatedButton(
                    "🎨 Aplicar y Visualizar",
                    on_click=on_aplicar_manual,
                    style=ft.ButtonStyle(bgcolor="#1A237E", color="white"),
                ),

                ft.Divider(height=6),

                # Simulación
                ft.Text("🎮 Simular cadena:", weight=ft.FontWeight.W_600, size=13),
                ft.Row([campo_cadena_sim,
                        ft.ElevatedButton("▶ Iniciar", on_click=on_iniciar_sim,
                                          style=ft.ButtonStyle(bgcolor="#2E7D32", color="white"))
                        ], spacing=8),
                ft.Row([
                    ft.ElevatedButton("◀ Anterior", on_click=on_paso_anterior),
                    ft.ElevatedButton("Siguiente ▶", on_click=on_paso_siguiente),
                    ft.ElevatedButton("⏭ Final", on_click=on_sim_completa),
                    ft.ElevatedButton("↺ Reset", on_click=on_reset),
                ], spacing=6, wrap=True),

            ], spacing=8, scroll=ft.ScrollMode.AUTO),

        ], spacing=16, wrap=True, vertical_alignment=ft.CrossAxisAlignment.START),

    ], spacing=12, scroll=ft.ScrollMode.AUTO)


# ══════════════════════════════════════════════════════════════════
#  DIBUJADO EN ft.canvas.Canvas
# ══════════════════════════════════════════════════════════════════

def _calcular_shapes(estados: list, transiciones: dict,
                     estado_inicial: str, estados_aceptacion: set,
                     estados_activos: set) -> list:
    """Calcula y retorna la lista de shapes del autómata (sin tocar el canvas)."""
    # Usamos el módulo ya importado al inicio del archivo como `canvas`
    c = canvas

    pos = _calcular_posiciones(estados)
    shapes = []

    # Fondo
    shapes.append(
        c.Rect(
            x=0,
            y=0,
            width=ANCHO_CANVAS,
            height=ALTO_CANVAS,
            paint=ft.Paint(color="#FAFAFA", style=ft.PaintingStyle.FILL),
        )
    )

    # ── Transiciones ──────────────────────────────────────────────
    arcos: dict = {}
    for src, trans in transiciones.items():
        for sym, dest in trans.items():
            destinos = dest if isinstance(dest, (set, frozenset, list)) else {dest}
            for d in destinos:
                d = str(d)
                if d and d != "∅" and d in pos:
                    arcos.setdefault((src, d), []).append(sym)

    pares_bidi = {(s, d) for (s, d) in arcos if (d, s) in arcos and s != d}

    for (src, dst), syms in arcos.items():
        etiqueta = ", ".join(syms)
        if src not in pos or dst not in pos:
            continue
        x1, y1 = pos[src]
        x2, y2 = pos[dst]
        es_activo = src in estados_activos and dst in estados_activos
        color_l   = "#F57F17" if es_activo else "#37474F"
        sw        = 2.5 if es_activo else 1.8

        paint_l = ft.Paint(
            color=color_l,
            stroke_width=sw,
            style=ft.PaintingStyle.STROKE,
        )

        if src == dst:
            # Auto-lazo: c.Arc no existe en Flet 0.24; se aproxima con un Path
            # usando dos QuadraticTo encadenados formando un óvalo
            lx, ly = x1, y1 - RADIO_ESTADO - 22
            rx_loop = 18
            ry_loop = 18
            top_y   = y1 - RADIO_ESTADO - 5
            shapes.append(c.Path(
                elements=[
                    c.Path.MoveTo(x1 - rx_loop, top_y),
                    c.Path.QuadraticTo(x1 - rx_loop * 2, top_y - ry_loop * 2,
                                       x1, top_y - ry_loop * 2),
                    c.Path.QuadraticTo(x1 + rx_loop * 2, top_y - ry_loop * 2,
                                       x1 + rx_loop, top_y),
                ],
                paint=paint_l,
            ))
            _agregar_punta(shapes, x1 + rx_loop, top_y,
                           math.atan2(1, 0.3), color_l, c)
            shapes.append(c.Text(
                value=etiqueta, x=lx, y=ly,
                style=ft.TextStyle(size=10, color=color_l,
                                   font_family="monospace",
                                   weight=ft.FontWeight.BOLD),
            ))
        else:
            curvar = (src, dst) in pares_bidi
            dx, dy = x2 - x1, y2 - y1
            dist = math.hypot(dx, dy) or 1
            ux, uy = dx / dist, dy / dist
            sx = x1 + ux * (RADIO_ESTADO + 2)
            sy = y1 + uy * (RADIO_ESTADO + 2)
            ex = x2 - ux * (RADIO_ESTADO + 14)
            ey = y2 - uy * (RADIO_ESTADO + 14)

            if curvar:
                px = (sx + ex) / 2 - uy * 45
                py = (sy + ey) / 2 + ux * 45
                lx = (sx + 2 * px + ex) / 4
                ly = (sy + 2 * py + ey) / 4 - 10
                # Construir elements directamente; ft.Path no existe en flet
                elementos = [
                    c.Path.MoveTo(sx, sy),
                    c.Path.QuadraticTo(px, py, ex, ey),
                ]
            else:
                lx = (sx + ex) / 2
                ly = (sy + ey) / 2 - 10
                elementos = [
                    c.Path.MoveTo(sx, sy),
                    c.Path.LineTo(ex, ey),
                ]

            shapes.append(c.Path(elements=elementos, paint=paint_l))

            # Punta de flecha manual
            ang = math.atan2(ey - sy, ex - sx)
            _agregar_punta(shapes, ex, ey, ang, color_l, c)

            # Etiqueta
            shapes.append(c.Text(
                value=etiqueta, x=lx, y=ly,
                style=ft.TextStyle(size=10, color=color_l,
                                   font_family="monospace",
                                   weight=ft.FontWeight.BOLD),
            ))

    # ── Flecha inicio ─────────────────────────────────────────────
    if estado_inicial in pos:
        xi, yi = pos[estado_inicial]
        sx2, sy2 = xi - RADIO_ESTADO - 2, yi
        shapes.append(c.Path(
            elements=[
                c.Path.MoveTo(xi - RADIO_ESTADO - 38, yi),
                c.Path.LineTo(sx2, sy2),
            ],
            paint=ft.Paint(color="#37474F", stroke_width=2,
                           style=ft.PaintingStyle.STROKE),
        ))
        ang = math.atan2(0, 1)
        _agregar_punta(shapes, sx2, sy2, ang, "#37474F", c)

    # ── Estados ───────────────────────────────────────────────────
    for est in estados:
        if est not in pos:
            continue
        x, y = pos[est]
        activo = est in estados_activos
        acept  = est in estados_aceptacion

        if activo and acept:
            fill_color = COLOR_ACEPT_ACT
        elif activo:
            fill_color = COLOR_ACTIVO
        elif acept:
            fill_color = COLOR_ACEPT
        else:
            fill_color = COLOR_NORMAL

        # Doble círculo para estados de aceptación
        if acept:
            shapes.append(c.Circle(
                x=x, y=y, radius=RADIO_ESTADO + 7,
                paint=ft.Paint(color=fill_color, stroke_width=2,
                               style=ft.PaintingStyle.STROKE),
            ))

        # Círculo relleno
        shapes.append(c.Circle(
            x=x, y=y, radius=RADIO_ESTADO,
            paint=ft.Paint(color=fill_color, style=ft.PaintingStyle.FILL),
        ))

        # Borde blanco
        shapes.append(c.Circle(
            x=x, y=y, radius=RADIO_ESTADO,
            paint=ft.Paint(color="white", stroke_width=2,
                           style=ft.PaintingStyle.STROKE),
        ))

        # Nombre del estado
        shapes.append(c.Text(
            value=est, x=x, y=y,
            style=ft.TextStyle(size=12, color="white",
                               font_family="monospace",
                               weight=ft.FontWeight.BOLD),
        ))

    return shapes


def _agregar_punta(shapes, ex, ey, ang, color, c):
    """Dibuja una punta de flecha triangular en (ex, ey) con ángulo ang."""
    tam = 10
    p1x = ex - tam * math.cos(ang - 0.4)
    p1y = ey - tam * math.sin(ang - 0.4)
    p2x = ex - tam * math.cos(ang + 0.4)
    p2y = ey - tam * math.sin(ang + 0.4)
    shapes.append(c.Path(
        elements=[
            c.Path.MoveTo(ex, ey),
            c.Path.LineTo(p1x, p1y),
            c.Path.LineTo(p2x, p2y),
            c.Path.Close(),
        ],
        paint=ft.Paint(color=color, style=ft.PaintingStyle.FILL),
    ))
