"""
logic_ap.py — Lógica para Autómatas con Pila (AP / PDA)
Práctica 5 · Ejercicio 2

Una transición del AP se define como:
    (estado_actual, símbolo_entrada, tope_pila) → (estado_siguiente, cadena_pila)

donde 'cadena_pila' es lo que se apila (puede ser vacía = pop, o varios símbolos = push múltiple).

Representación interna de transiciones:
    {
        estado: {
            (símbolo_entrada, tope_pila): [(estado_sig, cadena_push), ...]
        }
    }
    'λ' o '' se usa como epsilon (símbolo vacío).

El símbolo inicial de la pila es 'Z' por convención.
"""

from typing import Optional

EPSILON = "λ"   # epsilon visible en la UI
Z0      = "Z"   # símbolo de fondo de pila


# ══════════════════════════════════════════════════════════════
#  CLASE CONFIGURACIÓN (para seguimiento paso a paso)
# ══════════════════════════════════════════════════════════════

class ConfigAP:
    """Representa una configuración instantánea del AP."""
    __slots__ = ("estado", "entrada_restante", "pila")

    def __init__(self, estado: str, entrada_restante: str, pila: list):
        self.estado           = estado
        self.entrada_restante = entrada_restante
        self.pila             = list(pila)          # copia defensiva

    def __repr__(self):
        pila_str = "".join(reversed(self.pila)) if self.pila else "ε"
        entrada_str = self.entrada_restante if self.entrada_restante else "ε"
        return f"({self.estado}, {entrada_str}, {pila_str})"


# ══════════════════════════════════════════════════════════════
#  NORMALIZACIÓN DE TRANSICIONES
# ══════════════════════════════════════════════════════════════

def normalizar_transiciones(trans_raw: list) -> dict:
    """
    Convierte una lista plana de reglas al dict interno.

    trans_raw: lista de tuplas
        (estado_src, símbolo, tope_pila, estado_dst, push_str)

    Devuelve:
        {estado: {(sim, tope): [(dst, push), ...]}}
    """
    trans: dict = {}
    for (src, sym, tope, dst, push) in trans_raw:
        sym  = sym  if sym  else EPSILON
        tope = tope if tope else EPSILON
        push = push if push else ""       # "" = pop sin push
        trans.setdefault(src, {}).setdefault((sym, tope), []).append((dst, push))
    return trans


# ══════════════════════════════════════════════════════════════
#  OBTENER TRANSICIONES APLICABLES
# ══════════════════════════════════════════════════════════════

def _transiciones_aplicables(config: ConfigAP, trans: dict) -> list:
    """
    Dada una configuración devuelve lista de (dst, push_str, consumio_entrada)
    para todas las reglas que se pueden aplicar (con o sin epsilon en entrada).
    """
    resultado = []
    estado    = config.estado
    entrada   = config.entrada_restante
    tope      = config.pila[-1] if config.pila else ""

    reglas_estado = trans.get(estado, {})

    for (sym, tope_regla), destinos in reglas_estado.items():
        # Coincidencia de tope
        if tope_regla not in (tope, EPSILON):
            continue
        # Coincidencia de símbolo de entrada
        if sym == EPSILON or sym == "":
            # Transición epsilon: no consume entrada
            consumio = False
        elif entrada and entrada[0] == sym:
            consumio = True
        else:
            continue

        for (dst, push) in destinos:
            resultado.append((dst, push, consumio, tope_regla))

    return resultado


# ══════════════════════════════════════════════════════════════
#  APLICAR UNA TRANSICIÓN A UNA CONFIGURACIÓN
# ══════════════════════════════════════════════════════════════

def _aplicar(config: ConfigAP, dst: str, push: str,
             consumio: bool, tope_regla: str) -> ConfigAP:
    """Retorna la nueva configuración tras aplicar una transición."""
    nueva_pila   = list(config.pila)
    nueva_entrada = config.entrada_restante[1:] if consumio else config.entrada_restante

    # Operación sobre la pila
    if tope_regla != EPSILON and nueva_pila:
        nueva_pila.pop()                       # quitar tope

    # Apilar push (de derecha a izquierda para que el primero quede arriba)
    for ch in reversed(push):
        nueva_pila.append(ch)

    return ConfigAP(dst, nueva_entrada, nueva_pila)


# ══════════════════════════════════════════════════════════════
#  SIMULACIÓN COMPLETA (BFS limitado)
# ══════════════════════════════════════════════════════════════

def simular_AP(transiciones: dict,
               estado_inicial: str,
               estados_aceptacion: set,
               cadena: str,
               aceptar_por_estado: bool = True,
               aceptar_por_pila_vacia: bool = False,
               max_pasos: int = 500) -> dict:
    """
    Simula el AP sobre la cadena dada con BFS.

    Devuelve un dict con:
        aceptada         : bool
        camino           : lista de ConfigAP (un camino de aceptación si existe)
        todos_los_pasos  : lista de listas de ConfigAP por nivel BFS
        mensaje          : str descriptivo
    """
    pila_inicial = [Z0]
    config0      = ConfigAP(estado_inicial, cadena, pila_inicial)

    # BFS
    frontera  = [config0]
    visitados = set()
    camino_padre: dict = {id(config0): (None, None)}   # id -> (config_padre, desc)
    todos_los_pasos = [[config0]]
    pasos = 0

    def _acepta(c: ConfigAP) -> bool:
        por_estado    = aceptar_por_estado    and c.estado in estados_aceptacion and not c.entrada_restante
        por_pila_vac  = aceptar_por_pila_vacia and not c.pila and not c.entrada_restante
        return por_estado or por_pila_vac

    while frontera and pasos < max_pasos:
        siguiente: list = []
        for cfg in frontera:
            clave = (cfg.estado, cfg.entrada_restante, tuple(cfg.pila))
            if clave in visitados:
                continue
            visitados.add(clave)

            if _acepta(cfg):
                # Reconstruir camino
                camino = []
                nodo = cfg
                while nodo is not None:
                    camino.append(nodo)
                    nodo, _ = camino_padre.get(id(nodo), (None, None))
                camino.reverse()
                return {
                    "aceptada":        True,
                    "camino":          camino,
                    "todos_los_pasos": todos_los_pasos,
                    "mensaje":         "✅ ACEPTADA",
                }

            for (dst, push, consumio, tope_regla) in _transiciones_aplicables(cfg, transiciones):
                nuevo_cfg = _aplicar(cfg, dst, push, consumio, tope_regla)
                camino_padre[id(nuevo_cfg)] = (cfg, f"({cfg.estado},{cfg.entrada_restante or EPSILON},{cfg.pila[-1] if cfg.pila else EPSILON})→({dst},{push or EPSILON})")
                siguiente.append(nuevo_cfg)

        if siguiente:
            todos_los_pasos.append(list(siguiente))
        frontera = siguiente
        pasos += 1

    return {
        "aceptada":        False,
        "camino":          [config0],
        "todos_los_pasos": todos_los_pasos,
        "mensaje":         "❌ RECHAZADA",
    }


# ══════════════════════════════════════════════════════════════
#  SIMULACIÓN PASO A PASO (retorna pasos individuales del camino)
# ══════════════════════════════════════════════════════════════

def simular_AP_paso_a_paso(transiciones: dict,
                            estado_inicial: str,
                            estados_aceptacion: set,
                            cadena: str,
                            aceptar_por_estado: bool = True,
                            aceptar_por_pila_vacia: bool = False) -> list:
    """
    Retorna la lista de ConfigAP del camino de aceptación (o el camino más largo
    encontrado en BFS si no se acepta). Útil para la simulación interactiva.
    """
    resultado = simular_AP(transiciones, estado_inicial, estados_aceptacion,
                           cadena, aceptar_por_estado, aceptar_por_pila_vacia)
    return resultado["camino"], resultado["aceptada"]


# ══════════════════════════════════════════════════════════════
#  FORMATEAR RESULTADO LEGIBLE
# ══════════════════════════════════════════════════════════════

def formatear_resultado_ap(transiciones: dict,
                            estado_inicial: str,
                            estados_aceptacion: set,
                            cadena: str,
                            aceptar_por_estado: bool = True,
                            aceptar_por_pila_vacia: bool = False) -> str:
    camino, aceptada = simular_AP_paso_a_paso(
        transiciones, estado_inicial, estados_aceptacion,
        cadena, aceptar_por_estado, aceptar_por_pila_vacia
    )
    cadena_display = cadena if cadena else "ε (vacía)"
    lineas = [
        f"Cadena evaluada : {cadena_display}",
        f"Estado inicial  : {estado_inicial}",
        f"Estados acept.  : {{{', '.join(sorted(estados_aceptacion))}}}",
        f"Resultado       : {'✅ ACEPTADA' if aceptada else '❌ RECHAZADA'}",
        "",
        "Camino de configuraciones:",
    ]
    for i, cfg in enumerate(camino):
        pila_str   = "→".join(reversed(cfg.pila)) if cfg.pila else "ε"
        entrada_str = cfg.entrada_restante if cfg.entrada_restante else "ε"
        lineas.append(f"  Paso {i:2d}: estado={cfg.estado:6s}  entrada={entrada_str:10s}  pila=[{pila_str}]")
    return "\n".join(lineas)
