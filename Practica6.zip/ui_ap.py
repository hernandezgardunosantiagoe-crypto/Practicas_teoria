"""
ui_ap.py — Interfaz para Autómata con Pila (AP / PDA)
Práctica 5 · Ejercicio 2
Compatible con Flet 0.84.0

Sigue exactamente los mismos patrones que ui_visualizacion.py:
  - SVG para el grafo (no ft.canvas en la UI)
  - Sin ft.alignment, ft.Paint ni ft.PaintingStyle en la UI
  - update() protegido con try/except igual que en ui_visualizacion.py
"""
import math
import flet as ft

from logic_ap import (
    normalizar_transiciones,
    simular_AP_paso_a_paso,
    formatear_resultado_ap,
    EPSILON,
    Z0,
)
from ui_shared import mostrar_snack, abrir_ventana_resultado

# ══════════════════════════════════════════════════════════════
#  CONSTANTES DE DISEÑO
# ══════════════════════════════════════════════════════════════
RADIO      = 28
CW         = 700
CH         = 360
C_NORMAL   = "#1565C0"
C_ACTIVO   = "#F57F17"
C_ACEPT    = "#2E7D32"
C_AA       = "#FF6F00"
C_TRANS    = "#37474F"
C_FONDO    = "#FAFAFA"


# ══════════════════════════════════════════════════════════════
#  POSICIONES EN CÍRCULO
# ══════════════════════════════════════════════════════════════

def _posiciones(estados: list) -> dict:
    n = len(estados)
    if n == 0:
        return {}
    cx, cy = CW // 2, CH // 2
    r_layout = min(cx, cy) - RADIO - 30
    if n == 1:
        return {estados[0]: (cx, cy)}
    pos = {}
    for i, est in enumerate(estados):
        ang = (2 * math.pi * i / n) - math.pi / 2
        pos[est] = (int(cx + r_layout * math.cos(ang)),
                    int(cy + r_layout * math.sin(ang)))
    return pos


# ══════════════════════════════════════════════════════════════
#  GENERADOR DE SVG  (igual que ui_visualizacion.py)
# ══════════════════════════════════════════════════════════════

def _flecha_ap(x1, y1, x2, y2, etiqueta, color, stroke_w, curvar):
    dx, dy = x2 - x1, y2 - y1
    dist = math.hypot(dx, dy) or 1
    ux, uy = dx / dist, dy / dist
    sx = x1 + ux * (RADIO + 2)
    sy = y1 + uy * (RADIO + 2)
    ex = x2 - ux * (RADIO + 14)
    ey = y2 - uy * (RADIO + 14)

    marker = "url(#arrow_ap_act)" if color == C_ACTIVO else "url(#arrow_ap)"

    if curvar:
        px = (sx + ex) / 2 - uy * 40
        py = (sy + ey) / 2 + ux * 40
        path = f"M {sx:.1f},{sy:.1f} Q {px:.1f},{py:.1f} {ex:.1f},{ey:.1f}"
        lx = (sx + 2 * px + ex) / 4
        ly = (sy + 2 * py + ey) / 4 - 8
    else:
        path = f"M {sx:.1f},{sy:.1f} L {ex:.1f},{ey:.1f}"
        lx = (sx + ex) / 2
        ly = (sy + ey) / 2 - 8

    ancho_bg = len(etiqueta) * 6.5 + 8
    return "\n".join([
        f'<path d="{path}" stroke="{color}" stroke-width="{stroke_w}" '
        f'fill="none" marker-end="{marker}"/>',
        f'<rect x="{lx - ancho_bg/2:.1f}" y="{ly - 11:.1f}" '
        f'width="{ancho_bg:.1f}" height="14" fill="white" opacity="0.85" rx="3"/>',
        f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="middle" '
        f'font-size="9" fill="{color}" font-weight="bold" '
        f'font-family="monospace">{etiqueta}</text>',
    ])


def _loop_ap(x, y, etiqueta, color, stroke_w):
    marker = "url(#arrow_ap_act)" if color == C_ACTIVO else "url(#arrow_ap)"
    ry = y - RADIO - 5
    path = (f"M {x - 15},{ry + 5} "
            f"C {x - 40},{ry - 35} {x + 40},{ry - 35} {x + 15},{ry + 5}")
    lx, ly = x, ry - 28
    ancho_bg = len(etiqueta) * 6.5 + 8
    return "\n".join([
        f'<path d="{path}" stroke="{color}" stroke-width="{stroke_w}" '
        f'fill="none" marker-end="{marker}"/>',
        f'<rect x="{lx - ancho_bg/2:.1f}" y="{ly - 11:.1f}" '
        f'width="{ancho_bg:.1f}" height="14" fill="white" opacity="0.85" rx="3"/>',
        f'<text x="{lx}" y="{ly}" text-anchor="middle" '
        f'font-size="9" fill="{color}" font-weight="bold" '
        f'font-family="monospace">{etiqueta}</text>',
    ])


def _generar_svg_ap(estados: list, trans_raw: list,
                    estado_inicial: str, estados_aceptacion: set,
                    estado_activo: str) -> str:
    pos = _posiciones(estados)
    if not pos:
        return (f'<svg width="{CW}" height="{CH}" xmlns="http://www.w3.org/2000/svg">'
                f'<text x="20" y="40" fill="#888">Sin estados definidos.</text></svg>')

    partes = [
        f'<svg width="{CW}" height="{CH}" xmlns="http://www.w3.org/2000/svg">',
        f'<rect width="{CW}" height="{CH}" fill="{C_FONDO}" rx="10"/>',
        "<defs>",
        f'<marker id="arrow_ap" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">'
        f'<polygon points="0 0, 10 3.5, 0 7" fill="{C_TRANS}"/></marker>',
        f'<marker id="arrow_ap_act" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">'
        f'<polygon points="0 0, 10 3.5, 0 7" fill="{C_ACTIVO}"/></marker>',
        "</defs>",
    ]

    # Agrupar etiquetas por par (src, dst)
    arcos: dict = {}
    for (src, sym, tope, dst, push) in trans_raw:
        if src in pos and dst in pos:
            etiq = f"{sym or EPSILON},{tope or EPSILON}/{push or EPSILON}"
            arcos.setdefault((src, dst), []).append(etiq)

    pares_bidi = {(s, d) for (s, d) in arcos if (d, s) in arcos and s != d}

    for (src, dst), etiquetas in arcos.items():
        etiqueta = " | ".join(etiquetas)
        x1, y1 = pos[src]
        x2, y2 = pos[dst]
        es_activo = (src == estado_activo or dst == estado_activo)
        color  = C_ACTIVO if es_activo else C_TRANS
        stroke = "2.5" if es_activo else "1.8"

        if src == dst:
            partes.append(_loop_ap(x1, y1, etiqueta, color, stroke))
        else:
            curvar = (src, dst) in pares_bidi
            partes.append(_flecha_ap(x1, y1, x2, y2, etiqueta, color, stroke, curvar))

    # Flecha de estado inicial
    if estado_inicial in pos:
        xi, yi = pos[estado_inicial]
        partes.append(
            f'<line x1="{xi - RADIO - 35}" y1="{yi}" '
            f'x2="{xi - RADIO - 2}" y2="{yi}" '
            f'stroke="{C_TRANS}" stroke-width="2" marker-end="url(#arrow_ap)"/>'
            f'<text x="{xi - RADIO - 55}" y="{yi - 6}" '
            f'font-size="9" fill="{C_TRANS}">inicio</text>'
        )

    # Estados
    for est in estados:
        if est not in pos:
            continue
        x, y   = pos[est]
        activo = est == estado_activo
        acept  = est in estados_aceptacion

        if activo and acept:
            fill = C_AA
        elif activo:
            fill = C_ACTIVO
        elif acept:
            fill = C_ACEPT
        else:
            fill = C_NORMAL

        partes.append(f'<circle cx="{x+2}" cy="{y+2}" r="{RADIO}" fill="#00000022"/>')
        if acept:
            partes.append(
                f'<circle cx="{x}" cy="{y}" r="{RADIO + 6}" '
                f'fill="none" stroke="{fill}" stroke-width="2"/>'
            )
        partes.append(
            f'<circle cx="{x}" cy="{y}" r="{RADIO}" '
            f'fill="{fill}" stroke="white" stroke-width="2"/>'
        )
        partes.append(
            f'<text x="{x}" y="{y + 5}" text-anchor="middle" '
            f'font-size="12" fill="white" font-weight="bold" '
            f'font-family="monospace">{est}</text>'
        )

    partes.append("</svg>")
    return "\n".join(partes)


# ══════════════════════════════════════════════════════════════
#  WIDGET DE PILA (HTML/SVG embebido en ft.Image o como Column)
# ══════════════════════════════════════════════════════════════

def _construir_pila_col(pila: list) -> list:
    """Devuelve lista de ft.Container para representar la pila visualmente."""
    if not pila:
        return [ft.Container(
            content=ft.Text("(vacía)", size=11, color="#888888",
                            text_align=ft.TextAlign.CENTER),
            width=60, height=32, bgcolor="#F5F5F5",
            border=ft.border.all(1, "#CCCCCC"),
            border_radius=4,
        )]

    celdas = []
    for sym in reversed(pila):   # tope primero
        es_tope = (sym == pila[-1])
        bgcolor = "#FFF3E0" if es_tope else "#E3F2FD"
        borde_c = "#F57F17" if es_tope else "#90CAF9"
        borde_w = 2 if es_tope else 1
        celdas.append(ft.Container(
            content=ft.Text(sym, size=13, weight=ft.FontWeight.BOLD,
                            text_align=ft.TextAlign.CENTER,
                            color="#37474F"),
            width=60, height=34,
            bgcolor=bgcolor,
            border=ft.border.all(borde_w, borde_c),
            border_radius=4,
        ))

    celdas.append(ft.Container(
        content=ft.Text("─ Z ─", size=9, color="#888888",
                        text_align=ft.TextAlign.CENTER),
        width=60, height=18,
    ))
    return celdas


# ══════════════════════════════════════════════════════════════
#  SECCIÓN PRINCIPAL
# ══════════════════════════════════════════════════════════════

def seccion_ap(page: ft.Page) -> ft.Column:

    # ── Estado mutable ───────────────────────────────────────
    ap = {
        "estados":            ["q0", "q1", "q2"],
        "estado_inicial":     "q0",
        "estados_aceptacion": {"q2"},
        "trans_raw": [
            ("q0", "a", "Z", "q0", "AZ"),
            ("q0", "a", "A", "q0", "AA"),
            ("q0", "b", "A", "q1", ""),
            ("q1", "b", "A", "q1", ""),
            ("q1", "λ", "Z", "q2", "Z"),
        ],
    }

    sim = {"camino": [], "paso": 0, "aceptada": None}

    # ── Grafo SVG ────────────────────────────────────────────
    svg_img = ft.Image(
        src="",
        width=CW,
        height=CH,
        fit=ft.BoxFit.CONTAIN,
    )
    grafo_container = ft.Container(
        content=svg_img,
        border=ft.border.all(2, "#9FA8DA"),
        border_radius=10,
        bgcolor=C_FONDO,
        width=CW,
        height=CH,
    )

    # ── Labels ───────────────────────────────────────────────
    lbl_info    = ft.Text("", size=13, color="#37474F")
    lbl_paso    = ft.Text("Presiona ▶ Iniciar para simular.",
                          size=14, weight=ft.FontWeight.BOLD, color="#1565C0")
    lbl_entrada = ft.Text("", size=12, color="#555555", font_family="monospace")
    lbl_result  = ft.Text("", size=16, weight=ft.FontWeight.BOLD)

    # ── Pila visual ──────────────────────────────────────────
    pila_col = ft.Column([], spacing=2)

    def _actualizar_pila(pila: list):
        pila_col.controls = _construir_pila_col(pila)
        try:
            pila_col.update()
        except Exception:
            pass

    # ── Redibujar grafo ──────────────────────────────────────
    def _redibujar(estado_activo: str = ""):
        import base64
        svg = _generar_svg_ap(
            ap["estados"], ap["trans_raw"],
            ap["estado_inicial"], ap["estados_aceptacion"],
            estado_activo,
        )
        svg_img.src = base64.b64encode(svg.encode()).decode()
        try:
            svg_img.update()
            page.update()
        except Exception:
            pass

    # ═══════════════════════════════════════════════════════
    #  TABLA DE REGLAS
    # ═══════════════════════════════════════════════════════
    reglas_rows: list = []
    contenedor_reglas = ft.Column(scroll=ft.ScrollMode.AUTO, spacing=4)

    def _fila_campos(src="q0", sym="a", tope="Z", dst="q1", push=""):
        return [
            ft.TextField(value=src,  width=76,  height=38, text_size=11, hint_text="q0"),
            ft.TextField(value=sym,  width=76,  height=38, text_size=11, hint_text="a/λ"),
            ft.TextField(value=tope, width=76,  height=38, text_size=11, hint_text="Z/A"),
            ft.TextField(value=dst,  width=76,  height=38, text_size=11, hint_text="q1"),
            ft.TextField(value=push, width=110, height=38, text_size=11, hint_text="AZ / vacío=pop"),
        ]

    def _reconstruir_filas():
        contenedor_reglas.controls.clear()
        reglas_rows.clear()
        for idx, r in enumerate(ap["trans_raw"]):
            campos = _fila_campos(*r)
            reglas_rows.append(campos)
            # Botón eliminar como TextButton (sin ft.icons)
            btn_del = ft.TextButton(
                "✕",
                style=ft.ButtonStyle(color="#E53935"),
                tooltip="Eliminar regla",
                data=idx,
                on_click=_eliminar_regla,
            )
            contenedor_reglas.controls.append(
                ft.Row(campos + [btn_del], spacing=4)
            )
        try:
            contenedor_reglas.update()
        except Exception:
            pass

    def _eliminar_regla(e):
        idx = e.control.data
        if 0 <= idx < len(ap["trans_raw"]):
            ap["trans_raw"].pop(idx)
        _reconstruir_filas()
        _redibujar(ap["estado_inicial"])

    def on_agregar_regla(e):
        ap["trans_raw"].append(("q0", "a", "Z", "q1", ""))
        _reconstruir_filas()

    def _leer_reglas():
        nuevas = []
        for campos in reglas_rows:
            vals = tuple(tf.value.strip() for tf in campos)
            if any(vals):
                nuevas.append(vals)
        ap["trans_raw"] = list(nuevas)

    # ═══════════════════════════════════════════════════════
    #  CAMPOS GENERALES
    # ═══════════════════════════════════════════════════════
    campo_estados = ft.TextField(
        label="Estados (separados por comas)",
        value=", ".join(ap["estados"]),
        width=340,
    )
    campo_ei = ft.TextField(label="Estado inicial",         value=ap["estado_inicial"],              width=120)
    campo_ea = ft.TextField(label="Estados de aceptación",  value=", ".join(sorted(ap["estados_aceptacion"])), width=230)
    campo_cadena = ft.TextField(label="Cadena a simular (vacía = ε)", hint_text="Ej: aabb", width=240)

    chk_por_estado = ft.Checkbox(label="Por estado final", value=True)
    chk_por_pila   = ft.Checkbox(label="Por pila vacía",   value=False)

    # ═══════════════════════════════════════════════════════
    #  APLICAR CONFIGURACIÓN
    # ═══════════════════════════════════════════════════════
    def on_aplicar(e):
        _leer_reglas()
        ap["estados"]            = [s.strip() for s in campo_estados.value.split(",") if s.strip()]
        ap["estado_inicial"]     = campo_ei.value.strip() or "q0"
        ap["estados_aceptacion"] = {s.strip() for s in campo_ea.value.split(",") if s.strip()}

        sim["camino"] = []
        sim["paso"]   = 0
        sim["aceptada"] = None

        lbl_info.value    = f"AP | Estados: {len(ap['estados'])} | Reglas: {len(ap['trans_raw'])}"
        lbl_paso.value    = "Presiona ▶ Iniciar para simular."
        lbl_result.value  = ""
        lbl_entrada.value = ""
        _actualizar_pila([Z0])
        _redibujar(ap["estado_inicial"])

    # ═══════════════════════════════════════════════════════
    #  SIMULACIÓN PASO A PASO
    # ═══════════════════════════════════════════════════════
    def _mostrar_paso(paso: int):
        camino = sim["camino"]
        if not camino or paso >= len(camino):
            return
        cfg   = camino[paso]
        total = len(camino) - 1

        entrada_r = cfg.entrada_restante if cfg.entrada_restante else "ε"
        pila_str  = "→".join(reversed(cfg.pila)) if cfg.pila else "ε"

        lbl_paso.value    = f"Paso {paso}/{total}: estado = {cfg.estado}"
        lbl_entrada.value = f"Entrada restante: {entrada_r}   |   Pila (tope→): {pila_str}"

        if paso == total:
            lbl_result.value = "✅ ACEPTADA" if sim["aceptada"] else "❌ RECHAZADA"
            lbl_result.color = "#1B5E20"     if sim["aceptada"] else "#B71C1C"
        else:
            lbl_result.value = ""

        _actualizar_pila(cfg.pila)
        _redibujar(cfg.estado)
        try:
            page.update()
        except Exception:
            pass

    def on_iniciar(e):
        _leer_reglas()
        ap["estado_inicial"]     = campo_ei.value.strip() or "q0"
        ap["estados_aceptacion"] = {s.strip() for s in campo_ea.value.split(",") if s.strip()}

        trans = normalizar_transiciones(ap["trans_raw"])
        camino, aceptada = simular_AP_paso_a_paso(
            trans, ap["estado_inicial"], ap["estados_aceptacion"],
            campo_cadena.value,
            aceptar_por_estado     = chk_por_estado.value,
            aceptar_por_pila_vacia = chk_por_pila.value,
        )
        sim["camino"]   = camino
        sim["paso"]     = 0
        sim["aceptada"] = aceptada
        _mostrar_paso(0)

    def on_siguiente(e):
        if not sim["camino"]:
            mostrar_snack(page, "Primero inicia la simulación.")
            return
        if sim["paso"] + 1 >= len(sim["camino"]):
            mostrar_snack(page, "Ya llegaste al final.")
            return
        sim["paso"] += 1
        _mostrar_paso(sim["paso"])

    def on_anterior(e):
        if not sim["camino"] or sim["paso"] == 0:
            mostrar_snack(page, "Ya estás en el inicio.")
            return
        sim["paso"] -= 1
        _mostrar_paso(sim["paso"])

    def on_final(e):
        if not sim["camino"]:
            mostrar_snack(page, "Primero inicia la simulación.")
            return
        sim["paso"] = len(sim["camino"]) - 1
        _mostrar_paso(sim["paso"])

    def on_reset(e):
        sim["camino"]   = []
        sim["paso"]     = 0
        sim["aceptada"] = None
        lbl_paso.value    = "Presiona ▶ Iniciar para simular."
        lbl_result.value  = ""
        lbl_entrada.value = ""
        _actualizar_pila([Z0])
        _redibujar(ap["estado_inicial"])
        try:
            page.update()
        except Exception:
            pass

    def on_ver_resultado(e):
        _leer_reglas()
        ap["estado_inicial"]     = campo_ei.value.strip() or "q0"
        ap["estados_aceptacion"] = {s.strip() for s in campo_ea.value.split(",") if s.strip()}
        trans = normalizar_transiciones(ap["trans_raw"])
        texto = formatear_resultado_ap(
            trans, ap["estado_inicial"], ap["estados_aceptacion"],
            campo_cadena.value, chk_por_estado.value, chk_por_pila.value,
        )
        abrir_ventana_resultado(page, "Resultado AP", texto, sim.get("aceptada"), "resultado_ap.txt")

    # ═══════════════════════════════════════════════════════
    #  INICIALIZAR (sin update — el canvas aún no está en page)
    # ═══════════════════════════════════════════════════════
    _reconstruir_filas()

    # Dibujo inicial: construir SVG y asignarlo sin llamar update()
    import base64
    svg_init = _generar_svg_ap(
        ap["estados"], ap["trans_raw"],
        ap["estado_inicial"], ap["estados_aceptacion"],
        ap["estado_inicial"],
    )
    svg_img.src = base64.b64encode(svg_init.encode()).decode()

    pila_col.controls = _construir_pila_col([Z0])
    lbl_info.value    = f"AP | Estados: {len(ap['estados'])} | Reglas: {len(ap['trans_raw'])}"

    # ═══════════════════════════════════════════════════════
    #  LAYOUT  (igual que ui_visualizacion.py)
    # ═══════════════════════════════════════════════════════
    return ft.Column([
        ft.Text("🗂 Autómata con Pila (AP / PDA)",
                size=20, weight=ft.FontWeight.BOLD, color="#1A237E"),
        ft.Text(
            "Define las reglas de transición y simula cadenas paso a paso. "
            "La pila se muestra en tiempo real. "
            "Usa 'λ' para ε. Z = fondo de pila.",
            size=13, color="#555555",
        ),

        ft.Divider(height=8),

        ft.Row([
            # ── Columna izquierda: grafo + info ──────────
            ft.Column([
                grafo_container,
                lbl_info,
                lbl_paso,
                lbl_entrada,
                lbl_result,
            ], spacing=6),

            # ── Columna central: pila visual ──────────────
            ft.Column([
                ft.Text("Pila", size=13, weight=ft.FontWeight.W_600),
                ft.Text("(tope ↑)", size=10, color="#888888"),
                ft.Container(
                    content=pila_col,
                    border=ft.border.all(1, "#90CAF9"),
                    border_radius=8,
                    padding=8,
                    width=88,
                    height=290,
                    bgcolor="#FAFAFA",
                    clip_behavior=ft.ClipBehavior.HARD_EDGE,
                ),
            ], spacing=4, horizontal_alignment=ft.CrossAxisAlignment.CENTER),

            # ── Columna derecha: config + simulación ──────
            ft.Column([
                ft.Text("⚙ Configuración:", weight=ft.FontWeight.W_600, size=13),
                campo_estados,
                ft.Row([campo_ei, campo_ea], spacing=8),
                ft.Row([chk_por_estado, chk_por_pila], spacing=12),

                ft.Divider(height=6),

                ft.Text("📋 Reglas  (estado, símbolo, tope → edo.sig., push):",
                        size=12, weight=ft.FontWeight.W_600),
                ft.Text(
                    "Push: símbolos a apilar (tope queda primero). Vacío = solo pop.",
                    size=11, color="#777777",
                ),
                # Cabecera de tabla
                ft.Row([
                    ft.Container(ft.Text("Estado", size=10, weight=ft.FontWeight.BOLD),
                                 width=76, bgcolor="#E3F2FD", padding=4),
                    ft.Container(ft.Text("Símbolo", size=10, weight=ft.FontWeight.BOLD),
                                 width=76, bgcolor="#E3F2FD", padding=4),
                    ft.Container(ft.Text("Tope", size=10, weight=ft.FontWeight.BOLD),
                                 width=76, bgcolor="#E3F2FD", padding=4),
                    ft.Container(ft.Text("Edo.sig.", size=10, weight=ft.FontWeight.BOLD),
                                 width=76, bgcolor="#E3F2FD", padding=4),
                    ft.Container(ft.Text("Push", size=10, weight=ft.FontWeight.BOLD),
                                 width=110, bgcolor="#E3F2FD", padding=4),
                ], spacing=4),
                ft.Container(
                    content=contenedor_reglas,
                    border=ft.border.all(1, "#90CAF9"),
                    border_radius=8,
                    padding=8,
                    width=470,
                    height=180,
                    clip_behavior=ft.ClipBehavior.HARD_EDGE,
                ),
                ft.Row([
                    ft.ElevatedButton("+ Agregar regla", on_click=on_agregar_regla,
                                      style=ft.ButtonStyle(bgcolor="#455A64", color="white")),
                    ft.ElevatedButton("🎨 Aplicar / Visualizar", on_click=on_aplicar,
                                      style=ft.ButtonStyle(bgcolor="#1A237E", color="white")),
                ], spacing=8),

                ft.Divider(height=6),

                ft.Text("🎮 Simulación paso a paso:", weight=ft.FontWeight.W_600, size=13),
                ft.Row([
                    campo_cadena,
                    ft.ElevatedButton("▶ Iniciar", on_click=on_iniciar,
                                      style=ft.ButtonStyle(bgcolor="#2E7D32", color="white")),
                ], spacing=8),
                ft.Row([
                    ft.ElevatedButton("◀ Anterior", on_click=on_anterior),
                    ft.ElevatedButton("Siguiente ▶", on_click=on_siguiente),
                    ft.ElevatedButton("⏭ Final",     on_click=on_final),
                    ft.ElevatedButton("↺ Reset",      on_click=on_reset),
                ], spacing=6, wrap=True),
                ft.ElevatedButton("📄 Ver resultado completo", on_click=on_ver_resultado,
                                  style=ft.ButtonStyle(bgcolor="#37474F", color="white")),

            ], spacing=8, scroll=ft.ScrollMode.AUTO),

        ], spacing=16, wrap=True, vertical_alignment=ft.CrossAxisAlignment.START),

    ], spacing=12, scroll=ft.ScrollMode.AUTO)